"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/contexts/language-context"
import { translations } from "@/lib/translations"
import { quizQuestions } from "@/lib/quiz-data"
import { Home } from "lucide-react"

function QuizContent() {
  const { language } = useLanguage()
  const t = translations[language]
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [score, setScore] = useState(0)
  const [showResults, setShowResults] = useState(false)
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([])

  const handleAnswerClick = (optionIndex: number) => {
    const newAnswers = [...selectedAnswers]
    newAnswers[currentQuestion] = optionIndex
    setSelectedAnswers(newAnswers)

    if (optionIndex === quizQuestions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }

    if (currentQuestion < quizQuestions.length - 1) {
      setTimeout(() => {
        setCurrentQuestion(currentQuestion + 1)
      }, 500)
    } else {
      setTimeout(() => {
        setShowResults(true)
      }, 500)
    }
  }

  const restartQuiz = () => {
    setCurrentQuestion(0)
    setScore(0)
    setShowResults(false)
    setSelectedAnswers([])
  }

  if (showResults) {
    const percentage = Math.round((score / quizQuestions.length) * 100)

    return (
      <main className="min-h-screen bg-background">
        <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold">CA</span>
              </div>
              <h1 className="text-xl font-bold text-foreground hidden sm:block">Quiz</h1>
            </Link>
            <div className="flex gap-2 items-center">
              <LanguageToggle />
              <Link href="/">
                <Button variant="outline" size="sm" className="bg-transparent">
                  <Home className="w-4 h-4 mr-2" /> {t.home}
                </Button>
              </Link>
            </div>
          </div>
        </nav>

        <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl font-bold text-foreground">
                {language === "en" ? "Quiz Complete!" : "क्विज पूरा!"}
              </h1>
              <p className="text-lg text-muted-foreground">
                {language === "en" ? "Here's how you performed:" : "यहाँ आपका प्रदर्शन है:"}
              </p>
            </div>

            <Card className="border border-border p-8 space-y-6">
              <div className="space-y-2">
                <p className="text-6xl font-bold text-primary">{percentage}%</p>
                <p className="text-lg text-muted-foreground">
                  {language === "en"
                    ? `You scored ${score} out of ${quizQuestions.length}`
                    : `आपने ${quizQuestions.length} में से ${score} अंक प्राप्त किए`}
                </p>
              </div>

              <div className="space-y-3">
                {percentage >= 80 && (
                  <div className="text-center space-y-2">
                    <p className="text-2xl">🎉</p>
                    <p className="text-lg font-semibold text-accent">
                      {language === "en"
                        ? "Excellent! You have a great understanding of the Constitution!"
                        : "शानदार! आपको संविधान की गहरी समझ है!"}
                    </p>
                  </div>
                )}
                {percentage >= 60 && percentage < 80 && (
                  <div className="text-center space-y-2">
                    <p className="text-2xl">👍</p>
                    <p className="text-lg font-semibold text-accent">
                      {language === "en"
                        ? "Good! You have a solid understanding. Keep learning!"
                        : "अच्छा! आपकी अच्छी समझ है। सीखते रहें!"}
                    </p>
                  </div>
                )}
                {percentage < 60 && (
                  <div className="text-center space-y-2">
                    <p className="text-2xl">📚</p>
                    <p className="text-lg font-semibold text-accent">
                      {language === "en"
                        ? "Keep exploring! Read more and try again."
                        : "अन्वेषण करते रहें! और पढ़ें और दोबारा कोशिश करें।"}
                    </p>
                  </div>
                )}
              </div>

              <div className="grid sm:grid-cols-3 gap-4 pt-4">
                <Button onClick={restartQuiz} size="lg" className="w-full">
                  {language === "en" ? "Retake Quiz" : "क्विज फिर से लें"}
                </Button>
                <Link href="/read" className="w-full">
                  <Button variant="outline" size="lg" className="w-full bg-transparent">
                    {language === "en" ? "Read Constitution" : "संविधान पढ़ें"}
                  </Button>
                </Link>
                <Link href="/" className="w-full">
                  <Button variant="outline" size="lg" className="w-full bg-transparent">
                    {language === "en" ? "Go Home" : "होम जाएँ"}
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </main>
    )
  }

  const question = quizQuestions[currentQuestion]
  const isAnswered = selectedAnswers[currentQuestion] !== undefined

  return (
    <main className="min-h-screen bg-background">
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold">CA</span>
            </div>
            <h1 className="text-xl font-bold text-foreground hidden sm:block">Quiz</h1>
          </Link>
          <div className="flex gap-2 items-center">
            <LanguageToggle />
            <Link href="/">
              <Button variant="outline" size="sm" className="bg-transparent">
                <Home className="w-4 h-4 mr-2" /> {t.home}
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="space-y-8">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <p className="text-sm font-semibold text-muted-foreground">
                {language === "en"
                  ? `Question ${currentQuestion + 1} of ${quizQuestions.length}`
                  : `प्रश्न ${currentQuestion + 1} में से ${quizQuestions.length}`}
              </p>
              <p className="text-sm font-semibold text-accent">
                {language === "en" ? `Score: ${score}` : `स्कोर: ${score}`}
              </p>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Question Card */}
          <Card className="border border-border p-6 sm:p-8 space-y-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-foreground">
              {language === "en" ? question.questionEn : question.questionHi}
            </h2>

            {/* Options */}
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerClick(index)}
                  disabled={isAnswered}
                  className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                    selectedAnswers[currentQuestion] === index
                      ? index === question.correctAnswer
                        ? "border-accent bg-accent/10"
                        : "border-destructive bg-destructive/10"
                      : "border-border hover:border-primary"
                  } ${isAnswered ? "opacity-75 cursor-not-allowed" : "cursor-pointer"}`}
                >
                  <p className="font-semibold text-foreground">{language === "en" ? option.en : option.hi}</p>
                </button>
              ))}
            </div>

            {/* Explanation */}
            {isAnswered && (
              <div className="mt-6 p-4 rounded-lg bg-muted/50 space-y-2">
                <p className="text-sm font-semibold text-foreground">
                  {selectedAnswers[currentQuestion] === question.correctAnswer
                    ? language === "en"
                      ? "Correct!"
                      : "सही है!"
                    : language === "en"
                      ? "Incorrect"
                      : "गलत"}
                </p>
                <p className="text-sm text-muted-foreground">
                  {language === "en" ? question.explanationEn : question.explanationHi}
                </p>
              </div>
            )}

            {/* Navigation */}
            {isAnswered && (
              <div className="pt-4 flex gap-4">
                {currentQuestion < quizQuestions.length - 1 && (
                  <Button onClick={() => setCurrentQuestion(currentQuestion + 1)} className="w-full">
                    {language === "en" ? "Next Question" : "अगला प्रश्न"}
                  </Button>
                )}
                {currentQuestion === quizQuestions.length - 1 && (
                  <Button onClick={() => setShowResults(true)} className="w-full">
                    {language === "en" ? "See Results" : "परिणाम देखें"}
                  </Button>
                )}
              </div>
            )}
          </Card>
        </div>
      </div>
    </main>
  )
}

export default function QuizPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return <QuizContent />
}
