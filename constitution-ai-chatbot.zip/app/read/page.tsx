"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, BookOpen, Download, Home } from "lucide-react"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/contexts/language-context"
import { translations } from "@/lib/translations"
import { CONSTITUTION_PAGES } from "@/lib/constitution-data"

export default function ReadConstitution() {
  const { language } = useLanguage()
  const t = translations[language]
  const [currentPage, setCurrentPage] = useState(0)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (!user) {
      window.location.href = "/login"
    } else {
      setIsAuthenticated(true)
    }
  }, [])

  if (!isAuthenticated) {
    return null
  }

  const page = CONSTITUTION_PAGES[currentPage]
  const totalPages = CONSTITUTION_PAGES.length
  const pageTitle = language === "hi" ? page.titleHi : page.titleEn
  const pageContent = language === "hi" ? page.contentHi : page.contentEn

  const handlePreviousPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1)
      window.scrollTo(0, 0)
    }
  }

  const handleNextPage = () => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(currentPage + 1)
      window.scrollTo(0, 0)
    }
  }

  const handleDownload = () => {
    const fullText = CONSTITUTION_PAGES.map((p) => (language === "hi" ? p.contentHi : p.contentEn)).join("\n\n")
    const element = document.createElement("a")
    const file = new Blob([fullText], { type: "text/plain; charset=utf-8" })
    element.href = URL.createObjectURL(file)
    element.download = `Indian_Constitution_${language}.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between mb-4">
            <Link href="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition">
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">{t.home}</span>
            </Link>
            <div className="flex items-center gap-2">
              <LanguageToggle />
              <BookOpen className="w-5 h-5 text-primary" />
              <h1 className="text-xl font-bold text-foreground">{t.theConstitution}</h1>
            </div>
            <Button size="sm" variant="outline" onClick={handleDownload}>
              <Download className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">{t.download}</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Book Container */}
        <div className="bg-card border border-border rounded-lg shadow-lg overflow-hidden">
          {/* Page Content */}
          <div className="bg-white dark:bg-slate-900 p-8 sm:p-12 min-h-96 prose dark:prose-invert max-w-none">
            <h2 className="text-3xl font-bold text-foreground mb-4">{pageTitle}</h2>
            <p className="text-muted-foreground mb-6 text-sm">
              {t.pageOf} {currentPage + 1} {t.of} {totalPages}
            </p>
            <div className="text-foreground leading-relaxed whitespace-pre-wrap text-justify">{pageContent}</div>
          </div>

          {/* Navigation Bar */}
          <div className="border-t border-border bg-card/50 p-6">
            <div className="flex items-center justify-between gap-4">
              <Button onClick={handlePreviousPage} disabled={currentPage === 0} variant="outline" size="sm">
                <ChevronLeft className="w-4 h-4 mr-2" />
                {t.previous}
              </Button>

              {/* Page Indicator */}
              <div className="flex-1 flex items-center justify-center gap-2">
                <input
                  type="number"
                  min={1}
                  max={totalPages}
                  value={currentPage + 1}
                  onChange={(e) => {
                    const page = Number.parseInt(e.target.value) - 1
                    if (page >= 0 && page < totalPages) {
                      setCurrentPage(page)
                    }
                  }}
                  className="w-16 px-3 py-2 rounded-lg border border-border bg-background text-foreground text-center focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <span className="text-sm text-muted-foreground">
                  {t.of} {totalPages}
                </span>
              </div>

              <Button onClick={handleNextPage} disabled={currentPage === totalPages - 1} variant="outline" size="sm">
                {t.next}
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="mt-4 w-full bg-border rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentPage + 1) / totalPages) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-8 grid md:grid-cols-3 gap-4">
          <div className="bg-card border border-border rounded-lg p-4">
            <h3 className="font-semibold text-foreground mb-2">{t.preamble}</h3>
            <p className="text-sm text-muted-foreground">{t.preambleText}</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <h3 className="font-semibold text-foreground mb-2">{t.structure}</h3>
            <p className="text-sm text-muted-foreground">{t.structureText}</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <h3 className="font-semibold text-foreground mb-2">{t.amendments}</h3>
            <p className="text-sm text-muted-foreground">{t.amendmentsText}</p>
          </div>
        </div>
      </main>
    </div>
  )
}
