"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"

export default function Login() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showForgotPassword, setShowForgotPassword] = useState(false)
  const [resetEmail, setResetEmail] = useState("")
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(false)
  const [resetSent, setResetSent] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setErrors({})

    if (!email) setErrors((prev) => ({ ...prev, email: "Email is required" }))
    if (!password) setErrors((prev) => ({ ...prev, password: "Password is required" }))
    if (!email || !password) return

    setLoading(true)
    try {
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const user = users.find((u: any) => u.email === email && u.password === password)

      if (!user) {
        setErrors({ submit: "Invalid email or password" })
        setLoading(false)
        return
      }

      localStorage.setItem(
        "currentUser",
        JSON.stringify({
          id: user.id,
          fullName: user.fullName,
          email: user.email,
        }),
      )

      window.location.href = "/chat"
    } catch (error) {
      setErrors({ submit: "An error occurred. Please try again." })
    } finally {
      setLoading(false)
    }
  }

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!resetEmail) {
      setErrors({ resetEmail: "Email is required" })
      return
    }

    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const userExists = users.some((u: any) => u.email === resetEmail)

    if (!userExists) {
      setErrors({ resetEmail: "Email not found" })
      return
    }

    setResetSent(true)
    setTimeout(() => {
      setShowForgotPassword(false)
      setResetSent(false)
      setResetEmail("")
    }, 3000)
  }

  if (showForgotPassword) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Link href="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition mb-8">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>

          <Card className="p-8 border border-border shadow-lg">
            <div className="mb-8 text-center">
              <h1 className="text-3xl font-bold text-foreground mb-2">Reset Password</h1>
              <p className="text-muted-foreground">Enter your email to receive a reset link</p>
            </div>

            {resetSent ? (
              <div className="bg-accent/10 border border-accent/30 rounded-lg p-4 text-center">
                <p className="text-accent font-medium">Check your email for password reset instructions!</p>
              </div>
            ) : (
              <form onSubmit={handleForgotPassword} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Email Address</label>
                  <input
                    type="email"
                    value={resetEmail}
                    onChange={(e) => {
                      setResetEmail(e.target.value)
                      setErrors({})
                    }}
                    className="w-full px-4 py-2 rounded-lg border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    placeholder="you@example.com"
                  />
                  {errors.resetEmail && <p className="text-destructive text-sm mt-1">{errors.resetEmail}</p>}
                </div>

                <Button type="submit" className="w-full">
                  Send Reset Link
                </Button>
              </form>
            )}

            <button
              onClick={() => setShowForgotPassword(false)}
              className="text-center text-sm text-primary hover:text-primary/80 font-semibold transition mt-6 w-full"
            >
              Back to Login
            </button>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Link href="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition mb-8">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        <Card className="p-8 border border-border shadow-lg">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-foreground mb-2">Welcome Back</h1>
            <p className="text-muted-foreground">Sign in to your Constitution AI account</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value)
                  setErrors({})
                }}
                className="w-full px-4 py-2 rounded-lg border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                placeholder="you@example.com"
              />
              {errors.email && <p className="text-destructive text-sm mt-1">{errors.email}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value)
                  setErrors({})
                }}
                className="w-full px-4 py-2 rounded-lg border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                placeholder="••••••••"
              />
              {errors.password && <p className="text-destructive text-sm mt-1">{errors.password}</p>}
            </div>

            {errors.submit && <p className="text-destructive text-sm">{errors.submit}</p>}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Signing In..." : "Sign In"}
            </Button>
          </form>

          <button
            onClick={() => setShowForgotPassword(true)}
            className="text-center text-sm text-primary hover:text-primary/80 font-semibold transition mt-4 w-full"
          >
            Forgot Password?
          </button>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Don't have an account?{" "}
            <Link href="/signup" className="text-primary hover:text-primary/80 font-semibold transition">
              Sign Up
            </Link>
          </p>
        </Card>
      </div>
    </div>
  )
}
