"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronDown, Home, MessageCircle, BookOpen, LogOut, ArrowRight } from "lucide-react"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/contexts/language-context"
import { translations } from "@/lib/translations"

interface FAQItem {
  id: number
  category: string
  question: string
  answer: string
}

const FAQ_ITEMS: FAQItem[] = [
  {
    id: 1,
    category: "Basic Concepts",
    question: "What is the Indian Constitution?",
    answer: `The Indian Constitution is the supreme law of India. It was drafted by the Constituent Assembly under the leadership of Dr. B.R. Ambedkar and adopted on January 26, 1950. It defines the structure, powers, and procedures of the Indian government and establishes the fundamental rights and duties of citizens. It is the longest written constitution in the world with 395 Articles and 12 Schedules.`,
  },
  {
    id: 2,
    category: "Basic Concepts",
    question: "What is the Preamble of the Constitution?",
    answer: `The Preamble sets forth the objectives of the Constitution. It declares India to be a Sovereign Socialist Secular Democratic Republic and commits to securing Justice (social, economic, and political), Liberty of thought, expression, belief, faith and worship, Equality of status and of opportunity, and Fraternity assuring the dignity of the individual and the unity and integrity of the nation. The terms "Socialist" and "Secular" were added by the 42nd Amendment in 1976.`,
  },
  {
    id: 3,
    category: "Fundamental Rights",
    question: "What are Fundamental Rights?",
    answer: `Fundamental Rights are basic civil liberties granted to all citizens of India under Part III of the Constitution (Articles 12-35). These are inalienable rights that cannot be taken away by the government. Key fundamental rights include:
- Right to Equality (Articles 14-18)
- Right to Freedom (Articles 19-22)
- Right against Exploitation (Articles 23-24)
- Right to Freedom of Religion (Articles 25-28)
- Cultural and Educational Rights (Articles 29-30)
- Right to Constitutional Remedies (Articles 32-35)`,
  },
  {
    id: 4,
    category: "Fundamental Rights",
    question: "What is Article 14 (Right to Equality)?",
    answer: `Article 14 ensures that "the State shall not deny to any person equality before the law or the equal protection of the laws within the territory of India." This means:
1. All persons are equal before the law
2. All citizens have equal protection of laws
3. The State cannot discriminate arbitrarily
4. Laws must be applied equally to all
This is the foundation of equal citizenship in India and prevents discrimination by the government.`,
  },
  {
    id: 5,
    category: "Fundamental Rights",
    question: "What is the Right to Freedom (Article 19)?",
    answer: `Article 19 guarantees six fundamental freedoms to all citizens:
1. Freedom of speech and expression
2. Freedom to assemble peaceably and without arms
3. Freedom to form associations or unions
4. Freedom to move freely throughout India
5. Freedom to reside and settle in any part of India
6. Freedom to practice any profession or carry on any trade or business

However, these freedoms can be restricted by the State in the interests of national security, public order, morality, decency, and other specified grounds.`,
  },
  {
    id: 6,
    category: "Fundamental Rights",
    question: "What is Article 21 (Right to Life)?",
    answer: `Article 21 states: "No person shall be deprived of his life or personal liberty except according to procedure established by law." Initially interpreted narrowly, the Supreme Court has expanded it to include:
- Right to live with dignity
- Right to clean water and air
- Right to food and shelter
- Right to education
- Right to health
- Right to privacy
This is considered one of the most important and powerful articles of the Constitution.`,
  },
  {
    id: 7,
    category: "Government Structure",
    question: "What is the structure of the Indian Government?",
    answer: `The Indian Government is based on the parliamentary system and is structured in three levels:

1. UNION (National Government)
- President (Constitutional Head)
- Prime Minister (Executive Head)
- Parliament: Lok Sabha (House of the People) and Rajya Sabha (Council of States)
- Supreme Court

2. STATE GOVERNMENTS
- Governor (Constitutional Head)
- Chief Minister (Executive Head)
- State Legislature: Legislative Assembly and Legislative Council
- High Courts

3. LOCAL BODIES
- Municipal Corporations (Urban)
- Panchayats (Rural)

Each level has specific powers defined in the Constitution.`,
  },
  {
    id: 8,
    category: "Government Structure",
    question: "What is the difference between President and Prime Minister?",
    answer: `PRESIDENT:
- Constitutional head of the executive
- Elected by an Electoral College (Members of Parliament and State Legislatures)
- 5-year term
- Formal powers like giving assent to laws, issuing pardons
- Acts on advice of the Prime Minister and Cabinet

PRIME MINISTER:
- Head of the government
- Leader of the majority party/coalition in Lok Sabha
- Chosen by the President
- Holds office as long as he/she has support of Lok Sabha
- Exercises real executive power
- Leads the Council of Ministers

In simple terms: President is ceremonial head, Prime Minister is the real executive.`,
  },
  {
    id: 9,
    category: "Government Structure",
    question: "What are Lok Sabha and Rajya Sabha?",
    answer: `LOK SABHA (House of the People):
- Lower house of Parliament
- 545 members (530 from States, 15 from Union Territories, 2 Anglo-Indians)
- Elected directly by people every 5 years
- More powerful in financial matters
- Can be dissolved before term expires

RAJYA SABHA (Council of States):
- Upper house of Parliament
- 250 members (238 elected, 12 nominated)
- Members elected by State Assemblies for 6-year terms
- 1/3 members retire every 2 years
- Provides representation to States
- Cannot be dissolved

Lok Sabha is more powerful; Rajya Sabha checks and balances.`,
  },
  {
    id: 10,
    category: "Directive Principles",
    question: "What are Directive Principles of State Policy?",
    answer: `Directive Principles are guidelines for the governance of the country (Part IV, Articles 36-51). They are not enforceable in court but are fundamental to governance. Key principles include:

1. State to ensure welfare of people
2. Minimize inequality of income and status
3. Promote health and living standards
4. Provide free and compulsory education
5. Protect monuments and places of cultural importance
6. Promote international peace and security
7. Organize agriculture and animal husbandry
8. Protect environment and wildlife

These reflect the values of a welfare state and social justice that Dr. Ambedkar envisioned for India.`,
  },
  {
    id: 11,
    category: "Constitutional Amendments",
    question: "How can the Constitution be amended?",
    answer: `The Constitution can be amended through Article 368 using three procedures:

SIMPLE MAJORITY:
- Requires majority in both Houses of Parliament
- For amendments to rules of procedure

SPECIAL MAJORITY:
- Requires 2/3 majority in both Houses of Parliament
- Required for most amendments
- Example: 26th Amendment (voting age to 18)

SPECIAL MAJORITY + STATE RATIFICATION:
- 2/3 majority in both Houses
- Ratification by 1/2 of State legislatures
- Required for amendments affecting federal structure

Example amendments:
- 14th Amendment: Extended provisions to Union territories
- 42nd Amendment: Added "Socialist" and "Secular" to Preamble
- 73rd Amendment: Local government (Panchayats)`,
  },
  {
    id: 12,
    category: "Dr. Ambedkar",
    question: "Who was Dr. B.R. Ambedkar?",
    answer: `Dr. Bhimrao Ramji Ambedkar (1891-1956) was the principal architect of the Indian Constitution. Key facts about him:

BACKGROUND:
- First person from his community to attend college
- Obtained advanced degrees from Columbia University and London School of Economics
- Faced severe caste discrimination despite his achievements

CONTRIBUTIONS:
- Headed the Drafting Committee of the Constituent Assembly
- Fought against caste discrimination
- Champion of social justice and equality
- Advocated for rights of marginalized sections

VISION IN CONSTITUTION:
- Article 17: Abolition of Untouchability
- Equal rights for all citizens regardless of caste
- Social and economic justice
- Dignity and freedom for all

LEGACY:
- Transformed India's legal and social framework
- His vision of an egalitarian republic continues to guide India
- Remembered as one of the greatest leaders of India's independence movement`,
  },
]

export default function FAQPage() {
  const { language } = useLanguage()
  const t = translations[language]
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [selectedCategory, setSelectedCategory] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (!user) {
      window.location.href = "/login"
    } else {
      setIsAuthenticated(true)
    }
  }, [])

  if (!isAuthenticated) {
    return null
  }

  const categories = ["", ...Array.from(new Set(FAQ_ITEMS.map((item) => item.category)))]
  const filteredFAQ = selectedCategory ? FAQ_ITEMS.filter((item) => item.category === selectedCategory) : FAQ_ITEMS

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    window.location.href = "/"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition">
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">{t.home}</span>
            </Link>
            <div className="flex items-center gap-2">
              {/* Language Toggle */}
              <LanguageToggle />
              <h1 className="text-2xl font-bold text-foreground text-center flex-1">{t.faqTitle}</h1>
            </div>
            <Button size="sm" variant="outline" onClick={handleLogout}>
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Category Filter */}
        <div className="mb-8 flex flex-wrap gap-2">
          {categories.map((category) => (
            <button
              key={category || "all"}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                selectedCategory === category
                  ? "bg-primary text-primary-foreground"
                  : "bg-card border border-border text-foreground hover:border-primary"
              }`}
            >
              {category || t.allCategories}
            </button>
          ))}
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {filteredFAQ.map((item) => (
            <div
              key={item.id}
              className="bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition"
            >
              <button
                onClick={() => setExpandedId(expandedId === item.id ? null : item.id)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-muted/50 transition text-left"
              >
                <div className="flex-1">
                  <p className="text-xs font-semibold text-accent mb-1">{item.category}</p>
                  <h3 className="text-lg font-semibold text-foreground">{item.question}</h3>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-muted-foreground ml-4 transition-transform flex-shrink-0 ${
                    expandedId === item.id ? "transform rotate-180" : ""
                  }`}
                />
              </button>

              {expandedId === item.id && (
                <div className="px-6 py-4 border-t border-border bg-muted/30">
                  <p className="text-foreground leading-relaxed whitespace-pre-wrap">{item.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Quick Links */}
        <div className="mt-12 pt-8 border-t border-border">
          <h2 className="text-2xl font-bold text-foreground mb-6">{t.needHelp}</h2>
          <div className="grid sm:grid-cols-2 gap-6">
            <Link href="/chat">
              <div className="bg-card border border-border rounded-lg p-6 hover:border-primary/50 transition cursor-pointer">
                <MessageCircle className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-semibold text-foreground mb-2">{t.askAmbedkar}</h3>
                <p className="text-sm text-muted-foreground">{t.chatDesc}</p>
                <span className="inline-flex items-center mt-3 text-primary font-semibold">
                  {t.goToChat} <ArrowRight className="w-4 h-4 ml-2" />
                </span>
              </div>
            </Link>
            <Link href="/read">
              <div className="bg-card border border-border rounded-lg p-6 hover:border-primary/50 transition cursor-pointer">
                <BookOpen className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-semibold text-foreground mb-2">{t.readConstitution}</h3>
                <p className="text-sm text-muted-foreground">{t.readConstDesc}</p>
                <span className="inline-flex items-center mt-3 text-primary font-semibold">
                  {t.readNow} <ArrowRight className="w-4 h-4 ml-2" />
                </span>
              </div>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
