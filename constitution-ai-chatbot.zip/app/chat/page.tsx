"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Send, LogOut, BookOpen, HelpCircle, Home } from "lucide-react"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/contexts/language-context"
import { translations } from "@/lib/translations"
import { generateAmbedkarResponse } from "@/lib/ambedkar-ai"

interface Message {
  id: string
  text: string
  sender: "user" | "ambedkar"
  timestamp: Date
}

export default function ChatPage() {
  const { language } = useLanguage()
  const t = translations[language]
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [userName, setUserName] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (!user) {
      window.location.href = "/login"
    } else {
      const userData = JSON.parse(user)
      setUserName(userData.fullName.split(" ")[0])
      setIsAuthenticated(true)

      setMessages([
        {
          id: "0",
          text: t.greeting,
          sender: "ambedkar",
          timestamp: new Date(),
        },
      ])
    }
  }, [language, t])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const response = await generateAmbedkarResponse(input, language)
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: "ambedkar",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiMessage])
    } catch (error) {
      console.error("Error generating response:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: t.error,
        sender: "ambedkar",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    window.location.href = "/"
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">BA</span>
              </div>
              <div>
                <h1 className="text-lg font-bold text-foreground">{t.chatTitle}</h1>
                <p className="text-xs text-muted-foreground">{t.askQuestion}</p>
              </div>
            </Link>
            <div className="flex items-center gap-2">
              <LanguageToggle />
              <Link href="/">
                <Button size="sm" variant="outline" className="hidden sm:flex bg-transparent">
                  <Home className="w-4 h-4 mr-2" />
                  {t.home}
                </Button>
              </Link>
              <Link href="/read">
                <Button size="sm" variant="outline" className="hidden sm:flex bg-transparent">
                  <BookOpen className="w-4 h-4 mr-2" />
                  {t.read}
                </Button>
              </Link>
              <Link href="/faq">
                <Button size="sm" variant="outline" className="hidden sm:flex bg-transparent">
                  <HelpCircle className="w-4 h-4 mr-2" />
                  {t.faq}
                </Button>
              </Link>
              <Button size="sm" variant="outline" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          {messages.length === 1 && (
            <div className="grid sm:grid-cols-2 gap-4 mt-8">
              <div
                className="bg-card border border-border rounded-lg p-4 hover:border-primary/50 transition cursor-pointer"
                onClick={() => setInput(language === "en" ? "What are Fundamental Rights?" : "मौलिक अधिकार क्या हैं?")}
              >
                <h3 className="font-semibold text-foreground mb-2">{t.fundamentalRights}</h3>
                <p className="text-sm text-muted-foreground">{t.learnAboutRights}</p>
              </div>
              <div
                className="bg-card border border-border rounded-lg p-4 hover:border-primary/50 transition cursor-pointer"
                onClick={() =>
                  setInput(
                    language === "en" ? "Explain the Preamble of the Constitution" : "संविधान की प्रस्तावना को समझाएं",
                  )
                }
              >
                <h3 className="font-semibold text-foreground mb-2">{t.preamble}</h3>
                <p className="text-sm text-muted-foreground">{t.understandFoundation}</p>
              </div>
              <div
                className="bg-card border border-border rounded-lg p-4 hover:border-primary/50 transition cursor-pointer"
                onClick={() =>
                  setInput(language === "en" ? "What is the structure of Parliament?" : "संसद की संरचना क्या है?")
                }
              >
                <h3 className="font-semibold text-foreground mb-2">{t.parliament}</h3>
                <p className="text-sm text-muted-foreground">{t.howGovWorks}</p>
              </div>
              <div
                className="bg-card border border-border rounded-lg p-4 hover:border-primary/50 transition cursor-pointer"
                onClick={() =>
                  setInput(language === "en" ? "What are Directive Principles?" : "नीति निर्देशक सिद्धांत क्या हैं?")
                }
              >
                <h3 className="font-semibold text-foreground mb-2">{t.directives}</h3>
                <p className="text-sm text-muted-foreground">{t.partFour}</p>
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-2xl rounded-lg p-4 ${
                  message.sender === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border text-foreground"
                }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.text}</p>
                <span className="text-xs opacity-70 mt-2 block">
                  {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-card border border-border rounded-lg p-4 text-foreground">
                <div className="flex gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                  <div
                    className="w-2 h-2 bg-primary rounded-full animate-pulse"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-primary rounded-full animate-pulse"
                    style={{ animationDelay: "0.4s" }}
                  ></div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t border-border bg-card/50 backdrop-blur-sm sticky bottom-0">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <form onSubmit={handleSendMessage} className="flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t.chatPlaceholder}
              className="flex-1 px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              disabled={isLoading}
            />
            <Button type="submit" disabled={isLoading || !input.trim()} className="px-4 py-3">
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
