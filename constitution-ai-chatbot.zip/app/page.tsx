"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BookOpen, MessageCircle, Users, ArrowRight } from "lucide-react"
import { LanguageToggle } from "@/components/language-toggle"
import { useLanguage } from "@/contexts/language-context"
import { translations } from "@/lib/translations"

function HomeContent() {
  const { language } = useLanguage()
  const t = translations[language]

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold">CA</span>
            </div>
            <h1 className="text-xl font-bold text-foreground hidden sm:block">Constitution AI</h1>
          </div>
          <div className="flex gap-2 sm:gap-4 items-center">
            <LanguageToggle />
            <Link href="/login">
              <Button variant="outline" className="text-sm bg-transparent">
                {t.signIn}
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="text-sm">{t.getStarted}</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center space-y-8">
          <div className="inline-block px-4 py-2 bg-accent/10 rounded-full border border-accent/30">
            <p className="text-sm font-semibold text-accent">{t.welcomeToEducation}</p>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight">
            <span className="text-primary">{language === "en" ? "Dr. Ambedkar's" : "डॉ. अंबेडकर का"}</span>{" "}
            {language === "en" ? "Digital Guide to the Constitution" : "संविधान का डिजिटल गाइड"}
          </h1>

          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t.heroDesc}</p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
            <Link href="/chat">
              <Button size="lg" className="w-full sm:w-auto">
                {t.startChatting} <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link href="/read">
              <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
                <BookOpen className="mr-2 w-4 h-4" /> {t.readConstitution}
              </Button>
            </Link>
            <Link href="/quiz">
              <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
                <Users className="mr-2 w-4 h-4" /> {t.takeQuiz}
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="mt-20 grid md:grid-cols-3 gap-8">
          <Link href="/chat">
            <div className="bg-card border border-border rounded-lg p-6 space-y-4 hover:border-primary/50 transition cursor-pointer hover:shadow-md hover:-translate-y-1">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">{t.aiQA}</h3>
              <p className="text-sm text-muted-foreground">{t.aiQADesc}</p>
            </div>
          </Link>

          <Link href="/read">
            <div className="bg-card border border-border rounded-lg p-6 space-y-4 hover:border-primary/50 transition cursor-pointer hover:shadow-md hover:-translate-y-1">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">{t.readConstitution}</h3>
              <p className="text-sm text-muted-foreground">{t.readConstDesc}</p>
            </div>
          </Link>

          <Link href="/quiz">
            <div className="bg-card border border-border rounded-lg p-6 space-y-4 hover:border-primary/50 transition cursor-pointer hover:shadow-md hover:-translate-y-1">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">{t.quiz}</h3>
              <p className="text-sm text-muted-foreground">{t.quizDesc}</p>
            </div>
          </Link>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary/5 border-t border-border">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground">{t.readyToLearn}</h2>
          <p className="text-lg text-muted-foreground">{t.readyToLearnDesc}</p>
          <Link href="/signup">
            <Button size="lg">{t.createAccount}</Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 sm:px-6 lg:px-8 bg-foreground/5">
        <div className="max-w-7xl mx-auto grid sm:grid-cols-4 gap-8">
          <div className="space-y-3">
            <h4 className="font-semibold text-foreground">Constitution AI</h4>
            <p className="text-sm text-muted-foreground">
              {language === "en"
                ? "Learning the Constitution made simple and accessible."
                : "संविधान को सीखना सरल और सुलभ बनाया गया।"}
            </p>
          </div>
          <div className="space-y-3">
            <h5 className="font-semibold text-foreground">{t.platform}</h5>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>
                <Link href="/chat" className="hover:text-primary transition">
                  {language === "en" ? "Chat" : "चैट"}
                </Link>
              </li>
              <li>
                <Link href="/read" className="hover:text-primary transition">
                  {t.read}
                </Link>
              </li>
              <li>
                <Link href="/quiz" className="hover:text-primary transition">
                  {t.quiz}
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <h5 className="font-semibold text-foreground">{t.company}</h5>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary transition">
                  {t.about}
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition">
                  {t.contact}
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <h5 className="font-semibold text-foreground">{t.legal}</h5>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>
                <Link href="#" className="hover:text-primary transition">
                  {t.privacy}
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition">
                  {t.terms}
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>{t.copyright}</p>
        </div>
      </footer>
    </main>
  )
}

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return <HomeContent />
}
