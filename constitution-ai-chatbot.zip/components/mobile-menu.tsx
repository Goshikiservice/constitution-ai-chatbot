"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, BookOpen, MessageCircle, HelpCircle } from "lucide-react"

interface MobileMenuProps {
  authenticated?: boolean
}

export function MobileMenu({ authenticated }: MobileMenuProps) {
  const [isOpen, setIsOpen] = useState(false)

  if (!authenticated) return null

  return (
    <div className="sm:hidden fixed bottom-4 right-4 z-50">
      {isOpen && (
        <div className="absolute bottom-16 right-0 bg-card border border-border rounded-lg shadow-lg overflow-hidden">
          <div className="flex flex-col">
            <Link href="/chat" onClick={() => setIsOpen(false)}>
              <button className="w-full px-4 py-3 text-left hover:bg-muted/50 transition flex items-center gap-2 text-foreground">
                <MessageCircle className="w-4 h-4" />
                Chat
              </button>
            </Link>
            <Link href="/read" onClick={() => setIsOpen(false)}>
              <button className="w-full px-4 py-3 text-left hover:bg-muted/50 transition flex items-center gap-2 text-foreground border-t border-border">
                <BookOpen className="w-4 h-4" />
                Read Constitution
              </button>
            </Link>
            <Link href="/faq" onClick={() => setIsOpen(false)}>
              <button className="w-full px-4 py-3 text-left hover:bg-muted/50 transition flex items-center gap-2 text-foreground border-t border-border">
                <HelpCircle className="w-4 h-4" />
                FAQ
              </button>
            </Link>
          </div>
        </div>
      )}
      <Button
        size="lg"
        className="rounded-full w-14 h-14 flex items-center justify-center"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </Button>
    </div>
  )
}
