"use client"

import { useLanguage } from "@/contexts/language-context"
import { Button } from "@/components/ui/button"
import { Globe } from "lucide-react"

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage()

  return (
    <Button
      size="sm"
      variant="outline"
      onClick={() => setLanguage(language === "en" ? "hi" : "en")}
      className="bg-transparent"
      title="Toggle language / भाषा बदलें"
    >
      <Globe className="w-4 h-4 mr-2" />
      <span className="text-sm font-semibold">{language === "en" ? "हिंदी" : "English"}</span>
    </Button>
  )
}
