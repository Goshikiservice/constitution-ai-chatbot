export interface ConstitutionPage {
  id: string
  titleEn: string
  titleHi: string
  contentEn: string
  contentHi: string
}

export const CONSTITUTION_PAGES: ConstitutionPage[] = [
  {
    id: "preamble",
    titleEn: "Preamble",
    titleHi: "प्रस्तावना",
    contentEn: `WE, THE PEOPLE OF INDIA, having solemnly resolved to constitute India into a SOVEREIGN SOCIALIST SECULAR DEMOCRATIC REPUBLIC and to secure to all its citizens: JUSTICE, social, economic and political; LIBERTY of thought, expression, belief, faith and worship; EQUALITY of status and of opportunity; and to promote among them all FRATERNITY assuring the dignity of the individual and the unity and integrity of the Nation. IN OUR CONSTITUENT ASSEMBLY this twenty-sixth day of November, 1949, do HEREBY ADOPT, ENACT AND GIVE TO OURSELVES THIS CONSTITUTION.`,
    contentHi: `भारत के लोग, भारत को एक संपूर्ण प्रभुत्व संपन्न समाजवादी पंथनिरपेक्ष लोकतंत्रात्मक गणराज्य बनाने के लिए, तथा उसके सभी नागरिकों को: सामाजिक, आर्थिक और राजनीतिक न्याय, विचार, अभिव्यक्ति, विश्वास, धर्म और उपासना की स्वतंत्रता, स्थिति और अवसर की समानता, और उन सभी में व्यक्तिगत गरिमा और राष्ट्र की एकता और अखंडता सुनिश्चित करने के लिए बिरादरी बढ़ाने के लिए, सुनिश्चित करना चाहते हैं; अपनी संविधान सभा में इस छब्बीस नवंबर, 1949 को, हम अपने लिए यह संविधान अंगीकृत, अधिनियमित और दिया करते हैं।`,
  },
  {
    id: "article-1",
    titleEn: "Article 1: Name and Extent of the Union",
    titleHi: "अनुच्छेद 1: संघ का नाम और क्षेत्र",
    contentEn: `India, that is Bharat, shall be a Union of States. The States and the Union territories specified in the First Schedule shall form the Union. The territory of India shall comprise the territories of the States, the Union territories specified in the First Schedule, and such other territories as may be acquired.`,
    contentHi: `भारत अर्थात् भारत राज्यों का एक संघ होगा। प्रथम अनुसूची में विनिर्दिष्ट राज्य और संघ राज्यक्षेत्र संघ का गठन करेंगे। भारत का क्षेत्र राज्यों के क्षेत्र, प्रथम अनुसूची में विनिर्दिष्ट संघ राज्यक्षेत्र, और ऐसे अन्य क्षेत्र को शामिल होगा जो प्राप्त किए जा सकते हैं।`,
  },
  {
    id: "article-2",
    titleEn: "Article 2: Admission or establishment of new States",
    titleHi: "अनुच्छेद 2: नए राज्यों का प्रवेश या स्थापना",
    contentEn: `Parliament may by law admit into the Union, or establish, new States on such terms and conditions as it thinks fit.`,
    contentHi: `संसद कानून द्वारा संघ में नए राज्यों को प्रवेश दे सकती है या स्थापित कर सकती है जिन शर्तों को वह उचित समझे।`,
  },
  {
    id: "article-3",
    titleEn: "Article 3: Formation of new States and alteration of areas",
    titleHi: "अनुच्छेद 3: नए राज्यों का निर्माण और क्षेत्रों का परिवर्तन",
    contentEn: `Parliament may by law form a new State by separation of territory from any State or by uniting two or more States or parts of States, increase or diminish the area of any State, alter the boundaries of any State, or alter the name of any State.`,
    contentHi: `संसद किसी राज्य के क्षेत्र को अलग करके या दो या अधिक राज्यों या राज्यों के भागों को एकीकृत करके एक नया राज्य बना सकती है, किसी राज्य का क्षेत्र बढ़ा या घटा सकती है, किसी राज्य की सीमाओं को बदल सकती है, या किसी राज्य का नाम बदल सकती है।`,
  },
  {
    id: "article-5",
    titleEn: "Article 5: Citizenship at commencement of the Constitution",
    titleHi: "अनुच्छेद 5: संविधान के प्रारंभ में नागरिकता",
    contentEn: `At the commencement of this Constitution, every person who has his domicile in the territory of India and was born in the territory of India, or either of whose parents was born in the territory of India, or who has been ordinarily resident in the territory of India for not less than five years immediately preceding such commencement, shall be a citizen of India.`,
    contentHi: `इस संविधान के प्रारंभ में, हर व्यक्ति जो भारत के क्षेत्र में निवास रखता है और भारत के क्षेत्र में पैदा हुआ था, या जिसके माता-पिता में से कोई भारत के क्षेत्र में पैदा हुआ था, या जो इस प्रारंभ से तुरंत पहले कम से कम पाँच वर्ष के लिए भारत के क्षेत्र में सामान्यतः निवास करता रहा है, भारत का नागरिक होगा।`,
  },
  {
    id: "article-14",
    titleEn: "Article 14: Equality before the Law",
    titleHi: "अनुच्छेद 14: कानून के समक्ष समानता",
    contentEn: `The State shall not deny to any person equality before the law or the equal protection of the laws within the territory of India. This article is the foundation of civil rights and ensures that all citizens are treated equally by the government without discrimination based on religion, caste, sex, or place of birth.`,
    contentHi: `राज्य किसी भी व्यक्ति को भारत के क्षेत्र में कानून के समक्ष समानता या कानूनों का समान संरक्षण से नहीं रोकेगा। यह अनुच्छेद नागरिक अधिकारों की नींव है और सुनिश्चित करता है कि सभी नागरिकों को सरकार द्वारा धर्म, जाति, लिंग या जन्म स्थान के आधार पर भेदभाव के बिना समान व्यवहार किया जाए।`,
  },
  {
    id: "article-15",
    titleEn: "Article 15: Prohibition of discrimination on grounds of caste, religion, etc.",
    titleHi: "अनुच्छेद 15: धर्म, जाति आदि के आधार पर भेदभाव का निषेध",
    contentEn: `The State shall not discriminate against any citizen on grounds only of religion, race, caste, sex, place of birth or any of them. No citizen shall be subject to any disability, liability, restriction or condition with regard to access to shops, public restaurants, public entertainments, or the use of wells, tanks, bathing ghats, roads and places of public resort maintained wholly or partly out of State funds.`,
    contentHi: `राज्य किसी नागरिक के विरुद्ध केवल धर्म, नस्ल, जाति, लिंग, जन्म स्थान या इनमें से किसी के आधार पर भेदभाव नहीं करेगा। कोई नागरिक दुकानों, सार्वजनिक रेस्तरांओं, सार्वजनिक मनोरंजन, या राज्य निधि से पूरी या आंशिक रूप से रखे गए कुओं, टैंकों, स्नान घाटों, सड़कों और सार्वजनिक स्थलों के उपयोग के संबंध में किसी भी विकलांगता, दायित्व, प्रतिबंध या शर्त के अधीन नहीं होगा।`,
  },
  {
    id: "article-16",
    titleEn: "Article 16: Equality of opportunity in public employment",
    titleHi: "अनुच्छेद 16: सार्वजनिक नियोजन में अवसर की समानता",
    contentEn: `There shall be equality of opportunity for all citizens in matters relating to employment or appointment to any office under the State. No citizen shall be ineligible for or discriminated against in respect of any employment or office under the State on grounds only of religion, race, caste, sex, descent, place of birth or residence.`,
    contentHi: `सभी नागरिकों के लिए राज्य के अधीन किसी कार्यालय में नियोजन या नियुक्ति के संबंध में अवसरों की समानता होगी। कोई नागरिक केवल धर्म, नस्ल, जाति, लिंग, वंश, जन्म स्थान या निवास के आधार पर राज्य के अधीन किसी नियोजन या कार्यालय के लिए अयोग्य नहीं होगा या उसके साथ भेदभाव नहीं किया जाएगा।`,
  },
  {
    id: "article-17",
    titleEn: "Article 17: Abolition of Untouchability",
    titleHi: "अनुच्छेद 17: अस्पृश्यता का निषेध",
    contentEn: `"Untouchability" is hereby abolished and its practice in any form is forbidden. The enforcement of any disability arising out of "Untouchability" shall be an offence punishable in accordance with law. This article was particularly important to Dr. B.R. Ambedkar, who fought against caste-based discrimination throughout his life. Article 17 is one of the most powerful articles of the Indian Constitution as it abolished the ancient practice that had stigmatized millions of people on the basis of their caste.`,
    contentHi: `"अस्पृश्यता" का यहाँ निषेध किया जाता है और इसका किसी भी रूप में अभ्यास निषिद्ध है। अस्पृश्यता से उत्पन्न किसी भी अक्षमता को लागू करना कानून के अनुसार दंडनीय अपराध होगा। यह अनुच्छेद डॉ. बी.आर. अंबेडकर के लिए विशेष रूप से महत्वपूर्ण था, जिन्होंने अपने पूरे जीवन में जाति-आधारित भेदभाव के खिलाफ लड़ाई लड़ी। अनुच्छेद 17 भारतीय संविधान के सबसे शक्तिशाली अनुच्छेदों में से एक है क्योंकि इसने प्राचीन अभ्यास को समाप्त किया जो जाति के आधार पर लाखों लोगों को कलंकित करता था।`,
  },
  {
    id: "article-18",
    titleEn: "Article 18: Abolition of titles",
    titleHi: "अनुच्छेद 18: खिताबों का निषेध",
    contentEn: `No title, not being a military or academic distinction, shall be conferred by the State. No citizen of India shall accept any title from any foreign State. This article abolished titles like "Rai Sahib", "Khan", etc., promoting equality and removing class distinctions. The only exceptions are military decorations and academic distinctions.`,
    contentHi: `कोई भी खिताब, जो सैन्य या शैक्षणिक विशिष्टता न हो, राज्य द्वारा प्रदान नहीं किया जाएगा। भारत का कोई भी नागरिक किसी विदेशी राज्य से कोई खिताब स्वीकार नहीं करेगा। यह अनुच्छेद "राय साहब", "खान" आदि जैसे खिताबों को समाप्त करता है, समानता को बढ़ावा देता है और वर्ग विभेद को दूर करता है। एकमात्र अपवाद सैन्य सजावटें और शैक्षणिक विशिष्टताएं हैं।`,
  },
  {
    id: "article-19",
    titleEn: "Article 19: Protection of certain rights regarding freedom of speech, etc.",
    titleHi: "अनुच्छेद 19: भाषण की स्वतंत्रता आदि के संबंध में कुछ अधिकारों की सुरक्षा",
    contentEn: `All citizens shall have the right to freedom of speech and expression; freedom to assemble peaceably and without arms; freedom to form associations or unions; freedom to move freely throughout the territory of India; freedom to reside and settle in any part of the territory of India; and freedom to practise any profession, or to carry on any occupation, trade or business. The State may impose reasonable restrictions on these freedoms in the interests of the security of the State, public order, decency or morality.`,
    contentHi: `सभी नागरिकों को भाषण और अभिव्यक्ति की स्वतंत्रता, शांतिपूर्ण रूप से और बिना हथियारों के सभा की स्वतंत्रता, संघ या संघ बनाने की स्वतंत्रता, भारत के पूरे क्षेत्र में स्वतंत्र रूप से आने-जाने की स्वतंत्रता, भारत के क्षेत्र के किसी भी हिस्से में रहने और बसने की स्वतंत्रता, और किसी भी पेशे का अभ्यास करने या कोई व्यवसाय, व्यापार या व्यवसाय चलाने की स्वतंत्रता का अधिकार होगा। राज्य राज्य की सुरक्षा, सार्वजनिक व्यवस्था, शालीनता या नैतिकता के हितों में इन स्वतंत्रताओं पर उचित प्रतिबंध लगा सकता है।`,
  },
  {
    id: "article-20",
    titleEn: "Article 20: Protection in respect of conviction for offences",
    titleHi: "अनुच्छेद 20: अपराधों के लिए दोषसिद्धि के संबंध में संरक्षण",
    contentEn: `No person shall be convicted of any offence except for violation of a law in force at the time of the commission of the act charged as an offence, nor be subjected to a penalty greater than that which might have been inflicted under the law in force at the time of the commission of the offence. No person shall be prosecuted and punished for the same offence more than once. No person accused of any offence shall be compelled to be a witness against himself. This article provides protection against ex post facto laws, double jeopardy, and self-incrimination.`,
    contentHi: `कोई व्यक्ति किसी अपराध के लिए दोषसिद्ध नहीं किया जाएगा सिवाय उस कानून का उल्लंघन करने के जो अपराध के रूप में आरोपित कार्य के समय प्रवर्तन में था, और न ही उससे अधिक दंड का विषय होगा जो उस कानून के तहत लगाया जा सकता था। कोई व्यक्ति एक ही अपराध के लिए एक से अधिक बार अभियोजित और दंडित नहीं किया जाएगा। कोई भी व्यक्ति आरोपित अपराध के संबंध में अपने विरुद्ध साक्षी बनने के लिए बाध्य नहीं किया जाएगा।`,
  },
  {
    id: "article-21",
    titleEn: "Article 21: Protection of Life and Personal Liberty",
    titleHi: "अनुच्छेद 21: जीवन और व्यक्तिगत स्वतंत्रता का संरक्षण",
    contentEn: `No person shall be deprived of his life or personal liberty except according to procedure established by law. This is one of the most important articles of the Constitution. Initially interpreted narrowly, the Supreme Court has expanded it to include the right to clean water and air, right to food and shelter, right to education, right to health, right to privacy, and right to dignity. Article 21 has been used to strike down many laws and policies that violate human dignity and fundamental rights.`,
    contentHi: `कोई भी व्यक्ति कानून द्वारा स्थापित प्रक्रिया के अनुसार के बिना अपने जीवन या व्यक्तिगत स्वतंत्रता से वंचित नहीं किया जा सकता। यह संविधान के सबसे महत्वपूर्ण अनुच्छेदों में से एक है। प्रारंभ में संकीर्ण रूप से व्याख्यायित किया गया, सर्वोच्च न्यायालय ने इसे स्वच्छ पानी और हवा के अधिकार, भोजन और आश्रय के अधिकार, शिक्षा के अधिकार, स्वास्थ्य के अधिकार, गोपनीयता के अधिकार, और गरिमा के अधिकार को शामिल करने के लिए विस्तारित किया है।`,
  },
  {
    id: "article-22",
    titleEn: "Article 22: Protection against arrest and detention",
    titleHi: "अनुच्छेद 22: गिरफ्तारी और हिरासत के विरुद्ध संरक्षण",
    contentEn: `No person who is arrested shall be detained in custody without being informed, as soon as may be, of the grounds for such arrest nor shall he be denied the right to consult and be defended by a legal practitioner of his choice. Every person who is arrested and detained in custody shall be produced before the nearest magistrate within a period of twenty-four hours of such arrest excluding the time necessary for the journey from the place of arrest to the court of the magistrate. This article ensures the right to be informed of reasons for arrest, right to legal representation, and right to appear before a magistrate within 24 hours.`,
    contentHi: `गिरफ्तार किया गया कोई भी व्यक्ति यह सूचित किए बिना हिरासत में नहीं रखा जाएगा कि गिरफ्तारी के कारण क्या हैं, और न ही उसे अपनी पसंद के कानूनी चिकित्सक से परामर्श लेने और बचाव पाने के अधिकार से वंचित किया जाएगा। गिरफ्तार और हिरासत में रखा गया हर व्यक्ति गिरफ्तारी के चौबीस घंटे के भीतर निकटतम मजिस्ट्रेट के समक्ष प्रस्तुत किया जाएगा (गिरफ्तारी के स्थान से न्यायालय तक जाने के लिए आवश्यक समय को छोड़कर)।`,
  },
  {
    id: "fundamental-rights",
    titleEn: "Fundamental Rights Overview",
    titleHi: "मौलिक अधिकार अवलोकन",
    contentEn: `Part III of the Indian Constitution contains Fundamental Rights granted to all citizens. These are listed from Article 12 to Article 35 and include: (1) Equality before the law and equal protection, (2) Prohibition of discrimination on grounds of religion, race, caste, sex or place of birth, (3) Equality of opportunity in public employment, (4) Abolition of untouchability and titles, (5) Freedom of speech, assembly, association, movement, residence, and profession, (6) Protection against conviction for offences, (7) Protection of life and personal liberty, (8) Protection against arrest and detention. These rights are enforceable by the courts and are essential for a democratic nation.`,
    contentHi: `भारतीय संविधान के भाग III में मौलिक अधिकार हैं जो सभी नागरिकों को दिए गए हैं। ये अनुच्छेद 12 से अनुच्छेद 35 तक सूचीबद्ध हैं और इनमें शामिल हैं: (1) कानून के समक्ष समानता और समान संरक्षण, (2) धर्म, नस्ल, जाति, लिंग या जन्म स्थान के आधार पर भेदभाव का निषेध, (3) सार्वजनिक नियोजन में अवसर की समानता, (4) अस्पृश्यता और खिताबों का निषेध, (5) भाषण, सभा, संघ, आंदोलन, निवास और पेशे की स्वतंत्रता, (6) अपराधों के लिए दोषसिद्धि के विरुद्ध संरक्षण, (7) जीवन और व्यक्तिगत स्वतंत्रता का संरक्षण, (8) गिरफ्तारी और हिरासत के विरुद्ध संरक्षण। ये अधिकार न्यायालयों द्वारा प्रवर्तनीय हैं और एक लोकतांत्रिक राष्ट्र के लिए आवश्यक हैं।`,
  },
  {
    id: "directive-principles",
    titleEn: "Directive Principles of State Policy",
    titleHi: "राज्य नीति के निदेशक सिद्धांत",
    contentEn: `The Directive Principles of State Policy are principles for the governance of the country laid down in Part IV of the Indian Constitution (Articles 36-51). They are not enforceable in a court of law but are nevertheless recognized as fundamental in the governance of the country. It is the duty of the State to apply these principles in making laws. These principles guide the State in policy formulation and include ensuring social and economic justice, minimizing inequalities, protecting the environment, promoting education and culture, and securing welfare for all citizens.`,
    contentHi: `राज्य नीति के निदेशक सिद्धांत भारतीय संविधान के भाग IV में (अनुच्छेद 36-51) निर्धारित देश के शासन के लिए सिद्धांत हैं। ये न्यायालय में प्रवर्तनीय नहीं हैं लेकिन फिर भी देश के शासन के लिए मौलिक माने जाते हैं। कानून बनाते समय इन सिद्धांतों को लागू करना राज्य का कर्तव्य है। ये सिद्धांत नीति निर्माण में राज्य को निर्देशित करते हैं और सामाजिक और आर्थिक न्याय सुनिश्चित करने, असमानताओं को कम करने, पर्यावरण की सुरक्षा करने, शिक्षा और संस्कृति को बढ़ावा देने, और सभी नागरिकों के कल्याण को सुरक्षित करने को शामिल करते हैं।`,
  },
  {
    id: "parliament",
    titleEn: "Parliament: The Heart of Indian Democracy",
    titleHi: "संसद: भारतीय लोकतंत्र का हृदय",
    contentEn: `Part V of the Constitution (Articles 52-151) deals with the Executive, Legislative, and Judicial systems of the Union. Parliament of India consists of the President and two Houses: (1) Rajya Sabha (Council of States) - Upper house with 250 members representing States, (2) Lok Sabha (House of the People) - Lower house with 545 members directly elected by the people. Both houses have important roles: Lok Sabha is considered the more powerful house as it represents the will of the people through direct elections. Rajya Sabha represents the States and ensures that State interests are protected. Parliamentary proceedings are guided by rules made by each house, and all legislation must pass through both houses before becoming law.`,
    contentHi: `संविधान के भाग V (अनुच्छेद 52-151) में संघ की कार्यकारी, विधायी और न्यायिक प्रणालियों का वर्णन है। भारत की संसद में राष्ट्रपति और दो सदन शामिल हैं: (1) राज्य सभा (राज्यों की परिषद) - राज्यों का प्रतिनिधित्व करने वाला ऊपरी सदन जिसमें 250 सदस्य हैं, (2) लोक सभा (जनता का सदन) - निचला सदन जिसमें 545 सदस्य हैं जो जनता द्वारा सीधे चुने जाते हैं। दोनों सदनों की महत्वपूर्ण भूमिका है: लोक सभा को अधिक शक्तिशाली माना जाता है क्योंकि यह सीधे चुनावों के माध्यम से जनता की इच्छा का प्रतिनिधित्व करती है।`,
  },
  {
    id: "president",
    titleEn: "The President of India",
    titleHi: "भारत के राष्ट्रपति",
    contentEn: `The President is the constitutional head of the Union and holds office for a term of five years. According to Article 53, the executive power of the Union is vested in the President. However, in practice, the President acts on the advice of the Council of Ministers headed by the Prime Minister. The President performs both executive and ceremonial functions: Executive functions include approving bills passed by Parliament, granting pardons, and making certain appointments. Ceremonial functions include delivering addresses to Parliament and representing the nation at state functions. The President is elected by members of an Electoral College consisting of elected members of both Houses of Parliament and elected members of State Assemblies.`,
    contentHi: `राष्ट्रपति संघ का संवैधानिक प्रमुख है और पाँच साल की अवधि के लिए पद संभालता है। अनुच्छेद 53 के अनुसार, संघ की कार्यकारी शक्ति राष्ट्रपति में निहित है। व्यवहार में, राष्ट्रपति प्रधानमंत्री की अध्यक्षता में मंत्रियों की परिषद की सलाह पर कार्य करता है। राष्ट्रपति कार्यकारी और समारोहपूर्ण दोनों कार्य करता है: कार्यकारी कार्यों में संसद द्वारा पारित विधेयकों को मंजूरी देना, क्षमादान देना, और कुछ नियुक्तियाँ करना शामिल है।`,
  },
  {
    id: "ambedkar-legacy",
    titleEn: "Dr. B.R. Ambedkar: Architect of the Constitution",
    titleHi: "डॉ. बी.आर. अंबेडकर: संविधान के निर्माता",
    contentEn: `Dr. B.R. Ambedkar (1891-1956) was the principal architect of the Indian Constitution. He was born into an untouchable caste, experienced discrimination throughout his life, and dedicated himself to fighting for equality and justice. As Chairman of the Drafting Committee, Ambedkar led the effort to create a constitution that would grant equal rights and opportunities to all citizens, regardless of caste, religion, gender, or any other distinction. His vision was to establish: EQUALITY - All citizens equal before law, LIBERTY - Fundamental rights and freedoms for all, JUSTICE - Social, economic, and political justice, FRATERNITY - Unity and dignity of the nation. Ambedkar's most significant contribution was Article 17, which abolished untouchability - a practice that had oppressed millions for centuries. Famous quote: "If I find the Constitution being misused, I shall not hesitate to tell the world that my faith in the Constitution has been shaken."`,
    contentHi: `डॉ. बी.आर. अंबेडकर (1891-1956) भारतीय संविधान के प्रमुख निर्माता थे। वह एक अछूत जाति में पैदा हुए थे, अपने पूरे जीवन में भेदभाव का सामना किया, और समानता और न्याय के लिए लड़ने के लिए समर्पित थे। ड्राफ्टिंग समिति के अध्यक्ष के रूप में, अंबेडकर ने एक संविधान बनाने के प्रयास का नेतृत्व किया जो सभी नागरिकों को समान अधिकार और अवसर प्रदान करेगा। उनका दृष्टिकोण स्थापित करना था: समानता - कानून के समक्ष सभी नागरिक समान, स्वतंत्रता - सभी के लिए मौलिक अधिकार और स्वतंत्रता, न्याय - सामाजिक, आर्थिक और राजनीतिक न्याय, बिरादरी - राष्ट्र की एकता और गरिमा।`,
  },
]
