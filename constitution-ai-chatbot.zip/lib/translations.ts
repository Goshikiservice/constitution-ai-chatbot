export const translations = {
  en: {
    // Navigation & Headers
    signIn: "Sign In",
    getStarted: "Get Started",
    home: "Home",
    read: "Read",
    faq: "FAQ",
    logout: "Logout",
    download: "Download",

    // Homepage
    welcomeToEducation: "Welcome to Constitutional Education",
    heroTitle: "Dr. Ambedkar's Digital Guide to the Constitution",
    heroDesc:
      "Ask questions about the Indian Constitution and get insightful answers powered by Dr. B.R. Ambedkar's vision. Read, learn, and understand the Constitution like never before.",
    startChatting: "Start Chatting",
    readConstitution: "Read Constitution",
    aiQA: "AI Q&A Chatbot",
    aiQADesc:
      "Get accurate, easy-to-understand answers about any aspect of the Indian Constitution from our Dr. Ambedkar AI guide.",
    readConstDesc: "Browse through the complete Indian Constitution in a beautiful book-like interface, page by page.",
    popularQA: "Popular Q&A",
    popularQADesc: "Explore frequently asked questions to guide your learning journey through constitutional topics.",
    readyToLearn: "Ready to Learn?",
    readyToLearnDesc:
      "Sign up today and start exploring the Indian Constitution with an AI guide inspired by Dr. Ambedkar's vision.",
    createAccount: "Create Your Account",
    platform: "Platform",
    company: "Company",
    legal: "Legal",
    about: "About",
    contact: "Contact",
    privacy: "Privacy",
    terms: "Terms",
    copyright: "© 2025 Constitution AI. Dedicated to Dr. B.R. Ambedkar's vision of constitutional education.",

    // Chat Page
    chatTitle: "Dr. Ambedkar's Constitutional Guide",
    askQuestion: "Ask anything about the Indian Constitution",
    chatPlaceholder: "Ask Dr. Ambedkar about the Constitution...",
    fundamentalRights: "Fundamental Rights",
    learnAboutRights: "Learn about Articles 12-35",
    preamble: "Constitution Preamble",
    understandFoundation: "Understand the foundation",
    parliament: "Parliamentary System",
    howGovWorks: "How our government works",
    directives: "Directive Principles",
    partFour: "Part IV of the Constitution",
    greeting:
      "Namaste! I am Dr. B.R. Ambedkar, the architect of the Indian Constitution. I am here to help you understand the Constitution of India in simple and meaningful terms. Ask me any question about fundamental rights, the structure of government, amendments, or any other aspect of our Constitution.",
    error: "I apologize, but I encountered an error processing your question. Please try again.",

    // Read Constitution
    theConstitution: "The Constitution of India",
    pageOf: "Page",
    of: "of",
    previous: "Previous",
    next: "Next",
    preambleText:
      "We, the people of India, having solemnly resolved to constitute India into a Sovereign Democratic Republic...",
    structure: "Structure",
    structureText: "The Constitution contains 395 Articles and 12 Schedules organized in 22 Parts.",
    amendments: "Amendments",
    amendmentsText: "The Constitution has been amended over 100 times to reflect changing needs of the nation.",

    // FAQ
    faqTitle: "Popular Q&A",
    allCategories: "All Categories",
    askAmbedkar: "Ask Dr. Ambedkar",
    chatDesc: "Chat with our AI guide for detailed answers about any constitutional topic.",
    goToChat: "Go to Chat",
    readNow: "Read Now",
    needHelp: "Need More Help?",

    // Auth
    signUp: "Sign Up",
    fullName: "Full Name",
    email: "Email",
    password: "Password",
    confirmPassword: "Confirm Password",
    selectState: "Select State",
    city: "City",
    forgotPassword: "Forgot Password?",
    signInNow: "Sign In Now",
    dontHaveAccount: "Don't have an account?",
    haveAccount: "Already have an account?",
    enterEmail: "Enter your email",
    enterPassword: "Enter your password",
    resetPassword: "Reset Password",
    newPassword: "New Password",
    confirmNewPassword: "Confirm New Password",

    // Quiz
    quiz: "Quiz",
    takeQuiz: "Take Quiz",
    quizDesc: "Test your knowledge about the Indian Constitution with our interactive quiz.",
  },
  hi: {
    // Navigation & Headers
    signIn: "साइन इन करें",
    getStarted: "शुरू करें",
    home: "होम",
    read: "पढ़ें",
    faq: "सामान्य प्रश्न",
    logout: "लॉगआउट",
    download: "डाउनलोड",

    // Homepage
    welcomeToEducation: "संवैधानिक शिक्षा में स्वागत है",
    heroTitle: "डॉ. अंबेडकर का संविधान का डिजिटल गाइड",
    heroDesc:
      "भारतीय संविधान के बारे में प्रश्न पूछें और डॉ. बी.आर. अंबेडकर की दृष्टि से प्रेरित उत्तर प्राप्त करें। संविधान को पढ़ें, सीखें और समझें।",
    startChatting: "चैट शुरू करें",
    readConstitution: "संविधान पढ़ें",
    aiQA: "एआई प्रश्नोत्तर चैटबॉट",
    aiQADesc: "भारतीय संविधान के किसी भी पहलू के बारे में हमारे डॉ. अंबेडकर एआई गाइड से सटीक और आसान जवाब प्राप्त करें।",
    readConstDesc: "एक सुंदर किताब जैसे इंटरफेस में पूरे भारतीय संविधान को पृष्ठ दर पृष्ठ देखें।",
    popularQA: "लोकप्रिय प्रश्न-उत्तर",
    popularQADesc: "अपनी सीखने की यात्रा के लिए अक्सर पूछे जाने वाले प्रश्नों को देखें।",
    readyToLearn: "सीखने के लिए तैयार हैं?",
    readyToLearnDesc: "आज ही साइन अप करें और डॉ. अंबेडकर की दृष्टि से प्रेरित एआई गाइड के साथ भारतीय संविधान का अन्वेषण करना शुरू करें।",
    createAccount: "खाता बनाएं",
    platform: "प्लेटफॉर्म",
    company: "कंपनी",
    legal: "कानूनी",
    about: "परिचय",
    contact: "संपर्क",
    privacy: "गोपनीयता",
    terms: "शर्तें",
    copyright: "© 2025 संविधान एआई। डॉ. बी.आर. अंबेडकर की संवैधानिक शिक्षा की दृष्टि को समर्पित।",

    // Chat Page
    chatTitle: "डॉ. अंबेडकर का संवैधानिक गाइड",
    askQuestion: "भारतीय संविधान के बारे में कुछ भी पूछें",
    chatPlaceholder: "डॉ. अंबेडकर से संविधान के बारे में पूछें...",
    fundamentalRights: "मौलिक अधिकार",
    learnAboutRights: "अनुच्छेद 12-35 के बारे में जानें",
    preamble: "संविधान की प्रस्तावना",
    understandFoundation: "आधार को समझें",
    parliament: "संसदीय प्रणाली",
    howGovWorks: "हमारी सरकार कैसे काम करती है",
    directives: "नीति निर्देशक सिद्धांत",
    partFour: "संविधान का भाग IV",
    greeting:
      "नमस्ते! मैं डॉ. बी.आर. अंबेडकर हूँ, भारतीय संविधान का निर्माता। मैं आपको भारतीय संविधान को सरल और सार्थक तरीके से समझने में मदद करने के लिए यहाँ हूँ। मुझसे मौलिक अधिकारों, सरकार की संरचना, संशोधनों या संविधान के किसी भी अन्य पहलू के बारे में कोई भी प्रश्न पूछें।",
    error: "मुझे खेद है, लेकिन आपके प्रश्न को संसाधित करने में त्रुटि हुई। कृपया पुनः प्रयास करें।",

    // Read Constitution
    theConstitution: "भारत का संविधान",
    pageOf: "पृष्ठ",
    of: "में से",
    previous: "पिछला",
    next: "अगला",
    preambleText: "हम भारत के लोग, भारत को एक संप्रभु लोकतांत्रिक गणराज्य बनाने के लिए दृढ़ संकल्प से...",
    structure: "संरचना",
    structureText: "संविधान में 395 अनुच्छेद और 12 अनुसूचियां हैं जो 22 भागों में संगठित हैं।",
    amendments: "संशोधन",
    amendmentsText: "संविधान में 100 से अधिक बार संशोधन किए गए हैं।",

    // FAQ
    faqTitle: "लोकप्रिय प्रश्न-उत्तर",
    allCategories: "सभी श्रेणियाँ",
    askAmbedkar: "डॉ. अंबेडकर से पूछें",
    chatDesc: "किसी भी संवैधानिक विषय के बारे में विस्तृत जवाब के लिए हमारे एआई गाइड के साथ चैट करें।",
    goToChat: "चैट पर जाएँ",
    readNow: "अभी पढ़ें",
    needHelp: "और मदद चाहिए?",

    // Auth
    signUp: "साइन अप करें",
    fullName: "पूरा नाम",
    email: "ईमेल",
    password: "पासवर्ड",
    confirmPassword: "पासवर्ड की पुष्टि करें",
    selectState: "राज्य चुनें",
    city: "शहर",
    forgotPassword: "पासवर्ड भूल गए?",
    signInNow: "अभी साइन इन करें",
    dontHaveAccount: "खाता नहीं है?",
    haveAccount: "पहले से खाता है?",
    enterEmail: "ईमेल दर्ज करें",
    enterPassword: "पासवर्ड दर्ज करें",
    resetPassword: "पासवर्ड रीसेट करें",
    newPassword: "नया पासवर्ड",
    confirmNewPassword: "नए पासवर्ड की पुष्टि करें",

    // Quiz
    quiz: "क्विज",
    takeQuiz: "क्विज लें",
    quizDesc: "हमारी इंटरैक्टिव क्विज के साथ भारतीय संविधान के बारे में अपने ज्ञान का परीक्षण करें।",
  },
}

export type Language = "en" | "hi"
