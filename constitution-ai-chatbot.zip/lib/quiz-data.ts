export interface QuizQuestion {
  id: number
  questionEn: string
  questionHi: string
  options: {
    en: string
    hi: string
  }[]
  correctAnswer: number
  explanationEn: string
  explanationHi: string
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    questionEn: "In which year was the Indian Constitution adopted?",
    questionHi: "भारतीय संविधान किस वर्ष अपनाया गया था?",
    options: [
      { en: "1946", hi: "1946" },
      { en: "1949", hi: "1949" },
      { en: "1950", hi: "1950" },
      { en: "1951", hi: "1951" },
    ],
    correctAnswer: 1,
    explanationEn: "The Indian Constitution was adopted on January 26, 1950, and is celebrated as Republic Day.",
    explanationHi: "भारतीय संविधान 26 जनवरी 1950 को अपनाया गया था और इसे गणतंत्र दिवस के रूप में मनाया जाता है।",
  },
  {
    id: 2,
    questionEn: "Who is known as the architect of the Indian Constitution?",
    questionHi: "भारतीय संविधान का निर्माता किसे माना जाता है?",
    options: [
      { en: "Dr. B.R. Ambedkar", hi: "डॉ. बी.आर. अंबेडकर" },
      { en: "Jawaharlal Nehru", hi: "जवाहरलाल नेहरू" },
      { en: "Rajendra Prasad", hi: "राजेंद्र प्रसाद" },
      { en: "Sardar Vallabhbhai Patel", hi: "सरदार वल्लभभाई पटेल" },
    ],
    correctAnswer: 0,
    explanationEn: "Dr. B.R. Ambedkar, the principal architect of the Constitution, headed the Drafting Committee.",
    explanationHi: "डॉ. बी.आर. अंबेडकर, जो संविधान के प्रमुख वास्तुकार थे, ड्राफ्टिंग समिति की अध्यक्षता करते थे।",
  },
  {
    id: 3,
    questionEn: "How many Articles are there in the Indian Constitution?",
    questionHi: "भारतीय संविधान में कितने अनुच्छेद हैं?",
    options: [
      { en: "300", hi: "300" },
      { en: "350", hi: "350" },
      { en: "395", hi: "395" },
      { en: "420", hi: "420" },
    ],
    correctAnswer: 2,
    explanationEn: "The Constitution originally had 395 Articles organized into 22 Parts.",
    explanationHi: "संविधान में मूल रूप से 395 अनुच्छेद थे जो 22 भागों में संगठित थे।",
  },
  {
    id: 4,
    questionEn: "Which article guarantees the right to freedom of speech?",
    questionHi: "कौन सा अनुच्छेद भाषण की स्वतंत्रता का अधिकार देता है?",
    options: [
      { en: "Article 14", hi: "अनुच्छेद 14" },
      { en: "Article 19", hi: "अनुच्छेद 19" },
      { en: "Article 25", hi: "अनुच्छेद 25" },
      { en: "Article 32", hi: "अनुच्छेद 32" },
    ],
    correctAnswer: 1,
    explanationEn: "Article 19 guarantees the right to freedom of speech and expression.",
    explanationHi: "अनुच्छेद 19 भाषण और अभिव्यक्ति की स्वतंत्रता का अधिकार देता है।",
  },
  {
    id: 5,
    questionEn: "What is the term of office of the President of India?",
    questionHi: "भारत के राष्ट्रपति का कार्यकाल क्या है?",
    options: [
      { en: "4 years", hi: "4 साल" },
      { en: "5 years", hi: "5 साल" },
      { en: "6 years", hi: "6 साल" },
      { en: "7 years", hi: "7 साल" },
    ],
    correctAnswer: 1,
    explanationEn: "The President serves a term of 5 years and is eligible for re-election.",
    explanationHi: "राष्ट्रपति का कार्यकाल 5 साल का होता है और वह पुनः निर्वाचन के लिए पात्र हैं।",
  },
  {
    id: 6,
    questionEn: "Which article deals with the right to equality?",
    questionHi: "कौन सा अनुच्छेद समानता के अधिकार से संबंधित है?",
    options: [
      { en: "Article 12", hi: "अनुच्छेद 12" },
      { en: "Article 14", hi: "अनुच्छेद 14" },
      { en: "Article 21", hi: "अनुच्छेद 21" },
      { en: "Article 29", hi: "अनुच्छेद 29" },
    ],
    correctAnswer: 1,
    explanationEn: "Article 14 states that the state shall not deny any person equality before the law.",
    explanationHi: "अनुच्छेद 14 में कहा गया है कि राज्य किसी भी व्यक्ति को कानून के समक्ष समानता से वंचित नहीं करेगा।",
  },
  {
    id: 7,
    questionEn: "How many schedules does the Indian Constitution have?",
    questionHi: "भारतीय संविधान में कितनी अनुसूचियाँ हैं?",
    options: [
      { en: "8 Schedules", hi: "8 अनुसूचियाँ" },
      { en: "10 Schedules", hi: "10 अनुसूचियाँ" },
      { en: "12 Schedules", hi: "12 अनुसूचियाँ" },
      { en: "15 Schedules", hi: "15 अनुसूचियाँ" },
    ],
    correctAnswer: 2,
    explanationEn: "The Constitution has 12 Schedules, which contain lists of matters and territories.",
    explanationHi: "संविधान में 12 अनुसूचियाँ हैं, जिनमें विषयों और क्षेत्रों की सूचियाँ हैं।",
  },
  {
    id: 8,
    questionEn: "What is the minimum age to be eligible as a Member of Parliament?",
    questionHi: "संसद का सदस्य होने के लिए न्यूनतम आयु क्या है?",
    options: [
      { en: "21 years", hi: "21 साल" },
      { en: "25 years", hi: "25 साल" },
      { en: "30 years", hi: "30 साल" },
      { en: "35 years", hi: "35 साल" },
    ],
    correctAnswer: 1,
    explanationEn: "The minimum age to be a Member of Parliament (Lok Sabha) is 25 years.",
    explanationHi: "संसद (लोक सभा) का सदस्य होने के लिए न्यूनतम आयु 25 साल है।",
  },
  {
    id: 9,
    questionEn: "Which part of the Constitution deals with Fundamental Rights?",
    questionHi: "संविधान का कौन सा भाग मौलिक अधिकारों से संबंधित है?",
    options: [
      { en: "Part I", hi: "भाग I" },
      { en: "Part II", hi: "भाग II" },
      { en: "Part III", hi: "भाग III" },
      { en: "Part IV", hi: "भाग IV" },
    ],
    correctAnswer: 2,
    explanationEn: "Part III of the Constitution deals with Fundamental Rights (Articles 12-35).",
    explanationHi: "संविधान का भाग III मौलिक अधिकारों (अनुच्छेद 12-35) से संबंधित है।",
  },
  {
    id: 10,
    questionEn: "What is the official language of India as per the Constitution?",
    questionHi: "संविधान के अनुसार भारत की आधिकारिक भाषा क्या है?",
    options: [
      { en: "Hindi", hi: "हिंदी" },
      { en: "English", hi: "अंग्रेजी" },
      { en: "Both Hindi and English", hi: "हिंदी और अंग्रेजी दोनों" },
      { en: "Hindi only", hi: "केवल हिंदी" },
    ],
    correctAnswer: 0,
    explanationEn: "Hindi is the official language of India, though English is also used for government work.",
    explanationHi: "हिंदी भारत की आधिकारिक भाषा है, हालांकि अंग्रेजी का भी सरकारी कार्यों के लिए उपयोग किया जाता है।",
  },
]
