import { CONSTITUTION_PAGES } from "./constitution-data"
import type { Language } from "@/lib/translations"

const AI_RESPONSES: Record<Language, Record<string, string>> = {
  en: {
    "fundamental rights": `Fundamental Rights are the basic civil liberties guaranteed to all citizens of India under Part III of the Constitution (Articles 12-35). They include:

1. **Right to Equality** (Articles 14-18)
   - Equality before law
   - Prohibition of discrimination
   - Equality of opportunity in public employment
   - Abolition of untouchability
   - Abolition of titles

2. **Right to Freedom** (Articles 19-22)
   - Freedom of speech and expression
   - Freedom of assembly
   - Freedom of association
   - Freedom of movement
   - Freedom to practice profession

3. **Right against Exploitation** (Articles 23-24)
   - Prohibition of slavery and forced labor
   - Protection of children

4. **Right to Freedom of Religion** (Articles 25-28)
   - Freedom to profess, practice and propagate religion
   - Freedom from religious taxation
   - Freedom regarding education

5. **Cultural and Educational Rights** (Articles 29-30)
   - Protection of interests of minorities
   - Right to establish educational institutions

6. **Right to Constitutional Remedies** (Articles 32-35)
   - Right to move Supreme Court for protection of rights

These rights are enforceable in courts and can be used to challenge any law or government action that violates them.`,

    preamble: `The Preamble of the Constitution is the introductory section that outlines the objectives and principles of the Constitution. It reads:

"WE, THE PEOPLE OF INDIA, having solemnly resolved to constitute India into a SOVEREIGN SOCIALIST SECULAR DEMOCRATIC REPUBLIC and to secure to all its citizens:

JUSTICE, social, economic and political;
LIBERTY of thought, expression, belief, faith and worship;
EQUALITY of status and of opportunity;
and to promote among them all FRATERNITY assuring the dignity of the individual and the unity and integrity of the Nation;"

**Key Principles:**
- **Sovereign**: Free from external control
- **Socialist**: Aims to reduce inequality
- **Secular**: No official state religion
- **Democratic**: Power vested in the people
- **Republic**: Head of State is elected

The Preamble embodies the vision of Dr. Ambedkar and the Constituent Assembly for an egalitarian, just, and free India.`,

    "article 14": `Article 14 states: "The State shall not deny to any person equality before the law or the equal protection of the laws within the territory of India."

**What does this mean?**

1. **Equality before Law**: All persons, including the President and Prime Minister, are subject to the same law. No one is above the law.

2. **Equal Protection of Laws**: The laws must be applied equally to all persons in similar circumstances. The State cannot discriminate arbitrarily.

**Key Points:**
- Applies to both citizens and non-citizens
- The State cannot make laws that are discriminatory
- If a law discriminates arbitrarily, it can be challenged in court
- Reasonable classifications are permitted (e.g., progressive taxation)

**Examples:**
- Cannot punish a person for a crime they didn't commit based on caste
- Cannot deny employment based on religion
- Can have different age eligibility for retirement based on legitimate grounds

This article is the foundation of equal citizenship in India and has been extensively used by courts to protect individual rights.`,

    parliament: `Parliament is the supreme legislative body of India and consists of:

1. **President** (Constitutional role)

2. **Lok Sabha (House of the People)**
   - 545 members (530 from States, 15 from Union Territories, 2 Anglo-Indians)
   - Directly elected by people every 5 years
   - More powerful in financial matters
   - Can be dissolved before term ends

3. **Rajya Sabha (Council of States)**
   - 250 members (238 elected, 12 nominated)
   - Members elected by State Assemblies for 6-year terms
   - 1/3 retire every 2 years
   - Represents the interests of States

**Functions of Parliament:**
- Make laws for the country
- Control finances and budget
- Approve taxes and government expenditure
- Question ministers and hold them accountable
- Amend the Constitution

**How a Bill becomes Law:**
1. Bill is introduced in either house
2. Discussed and debated
3. Voted upon
4. Passed to the other house
5. Same process in other house
6. If passed by both, sent to President
7. President gives assent - Bill becomes Law

Parliament is the heart of India's democratic system.`,

    president: `The President is the constitutional head of the executive in India.

**Election:**
- Elected by Electoral College consisting of:
  - All elected members of Lok Sabha and Rajya Sabha
  - All elected members of State Legislative Assemblies
- Uses weighted voting system for uniformity

**Term:**
- 5 years
- Can be re-elected for a second term
- After two full consecutive terms, not eligible

**Qualifications:**
- Indian citizen
- At least 35 years old
- Qualified to be elected to Lok Sabha
- Not held office for two consecutive terms

**Powers and Functions:**
- Appoints Prime Minister (leader of majority in Lok Sabha)
- Appoints Chief Ministers and Governors
- Gives assent to laws passed by Parliament
- Can grant pardons and commute sentences
- Commander-in-Chief of Armed Forces
- Addresses Parliament on important occasions
- Can dissolve Lok Sabha

**Acting on Advice:**
- President exercises most powers on advice of Prime Minister and Cabinet
- Acts are countersigned by Cabinet members
- President cannot act arbitrarily

The President is a ceremonial head, but holds important symbolic power as guardian of the Constitution.`,

    "article 17": `Article 17 is one of the most powerful and significant articles of the Constitution: "Untouchability is hereby abolished and its practice in any form is forbidden. The enforcement of any disability arising out of Untouchability shall be an offence punishable in accordance with law."

**Historical Significance:**
This article abolished the ancient practice of untouchability - a caste-based system that declared certain communities as "untouchable" and subjected them to severe discrimination and humiliation.

**What it Means:**
- Untouchability is completely forbidden
- Cannot practice or enforce any disability based on untouchability
- Violations are criminal offenses
- Equal dignity for all humans regardless of caste

**Dr. Ambedkar's Contribution:**
This article was particularly important to Dr. Ambedkar, who:
- Faced severe caste discrimination himself
- Fought throughout his life against caste-based inequality
- Made abolition of untouchability a core principle of the Constitution
- Envisioned a society based on equality and human dignity

**Related Articles:**
- Article 14: Prohibition of discrimination
- Article 15: Prohibition on grounds of caste
- Article 16: Equality in public employment
- Article 23: Prohibition of forced labor

Abolition of untouchability was a revolutionary step in making India a truly egalitarian society.`,

    "directive principles": `Directive Principles of State Policy (Part IV, Articles 36-51) are guidelines for governance that are NOT enforceable in courts but are fundamental to the governance of the country.

**Key Principles:**

1. **Social and Economic Justice**
   - State to promote welfare and minimize inequality
   - Ensure decent living conditions

2. **Education**
   - Free and compulsory education up to age 14
   - Promote literacy and learning

3. **Public Health**
   - Improve public health and nutrition
   - Prevent diseases

4. **Protection of Environment**
   - Protect and improve natural environment
   - Wildlife conservation
   - Preserve monuments and culture

5. **Labor Rights**
   - Secure just working conditions
   - Social security and old age benefits
   - Protection for workers

6. **Agriculture and Animal Welfare**
   - Improve farming and cattle breeding
   - Prevent animal cruelty

7. **International Peace**
   - Promote international peace and security
   - Respect for international law

**Why Not Enforceable?**
- Meant to be aspirational goals
- Require resources and time to implement
- Flexibility for democratic government

**Importance:**
- Reflect values of welfare state
- Guide legislation and policies
- Represent vision of equality and social justice

**Implementation:**
- States pass laws to implement principles
- Courts can refer to them when interpreting laws
- Many principles now incorporated into fundamental rights through amendments

These principles embody Dr. Ambedkar's vision of a just and equal society.`,

    "article 21": `Article 21: "No person shall be deprived of his life or personal liberty except according to procedure established by law."

**Evolution of Interpretation:**

Initially, this article was interpreted narrowly to mean only procedural due process. However, the Supreme Court has expanded it to include substantive rights:

**Rights Derived from Article 21:**
- Right to live with human dignity
- Right to clean water and air
- Right to adequate food and nutrition
- Right to shelter
- Right to education
- Right to health and medical care
- Right to privacy
- Right to freedom of movement
- Right to fair trial

**Landmark Cases:**
- Maneka Gandhi vs. Union of India: Expanded meaning of "procedure"
- Olga Tellis vs. Bombay Municipality: Right to livelihood
- Sukhdev Singh vs. Govt. of Punjab: Right to justice

**Safeguards:**
- Cannot be deprived except through legal procedure
- Law must be fair, just, and reasonable
- Not arbitrary or whimsical

**Limitations:**
- Capital punishment allowed (with due procedure)
- State can restrict liberty for public interest
- Must follow established law

**Significance:**
Article 21 has become one of the most powerful tools for protecting human rights and dignity. It has been used to strike down unfair laws and practices across various areas - from death penalty cases to environmental protection.

This article truly embodies the vision of a constitutional democracy that protects fundamental human dignity.`,
  },
  hi: {
    "मौलिक अधिकार": `मौलिक अधिकार भारतीय संविधान के भाग III (अनुच्छेद 12-35) के तहत सभी नागरिकों को दिए गए बुनियादी नागरिक अधिकार हैं। इनमें शामिल हैं:

1. **समानता का अधिकार** (अनुच्छेद 14-18)
   - कानून के सामने समानता
   - भेदभाव पर प्रतिबंध
   - सार्वजनिक रोजगार में समान अवसर
   - अस्पृश्यता को खत्म करना
   - शीर्षकों को समाप्त करना

2. **स्वतंत्रता का अधिकार** (अनुच्छेद 19-22)
   - भाषण और अभिव्यक्ति की स्वतंत्रता
   - सभा की स्वतंत्रता
   - संगठन बनाने की स्वतंत्रता
   - आंदोलन की स्वतंत्रता
   - व्यवसाय करने की स्वतंत्रता

3. **शोषण के विरुद्ध अधिकार** (अनुच्छेद 23-24)
   - दासता और जबरदस्ती श्रम पर प्रतिबंध
   - बच्चों की सुरक्षा

4. **धर्म की स्वतंत्रता का अधिकार** (अनुच्छेद 25-28)
   - धर्म को मानने और प्रचार की स्वतंत्रता
   - धार्मिक कर से मुक्ति
   - शिक्षा से संबंधित स्वतंत्रता

5. **सांस्कृतिक और शैक्षणिक अधिकार** (अनुच्छेद 29-30)
   - अल्पसंख्यकों के हितों की सुरक्षा
   - शैक्षणिक संस्थान स्थापित करने का अधिकार

6. **संवैधानिक उपचार का अधिकार** (अनुच्छेद 32-35)
   - अधिकारों की सुरक्षा के लिए सर्वोच्च न्यायालय में याचिका दाखिल करने का अधिकार

ये अधिकार अदालतों में लागू किए जा सकते हैं और किसी भी कानून या सरकारी कार्रवाई को चुनौती देने के लिए उपयोग किए जा सकते हैं।`,

    प्रस्तावना: `संविधान की प्रस्तावना एक परिचयात्मक अनुभाग है जो संविधान के उद्देश्यों और सिद्धांतों को रेखांकित करती है। यह इस प्रकार पढ़ी जाती है:

"हम, भारत के लोग, भारत को एक संप्रभु समाजवादी पंथनिरपेक्ष लोकतांत्रिक गणराज्य बनाने के लिए दृढ़ संकल्प से अपने सभी नागरिकों को सुरक्षित करने के लिए:

न्याय - सामाजिक, आर्थिक और राजनीतिक;
स्वतंत्रता - विचार, अभिव्यक्ति, विश्वास, आस्था और पूजा की;
समानता - स्थिति और अवसर की;
और उनमें सभी के बीच बंधुत्व को बढ़ावा देने के लिए जो व्यक्ति की गरिमा और राष्ट्र की एकता और अखंडता को सुनिश्चित करता है।"

**मुख्य सिद्धांत:**
- **संप्रभु**: बाहरी नियंत्रण से मुक्त
- **समाजवादी**: असमानता को कम करने का लक्ष्य
- **पंथनिरपेक्ष**: कोई आधिकारिक राज्य धर्म नहीं
- **लोकतांत्रिक**: शक्ति जनता में निहित
- **गणराज्य**: राज्य के प्रमुख का चुनाव किया जाता है

प्रस्तावना डॉ. अंबेडकर और संविधान सभा की एक समतावादी, न्यायसंगत और मुक्त भारत की दृष्टि को प्रतिबिंबित करती है।`,

    "अनुच्छेद 14": `अनुच्छेद 14 कहता है: "राज्य किसी व्यक्ति को कानून के समक्ष समानता या भारत के राज्य क्षेत्र के भीतर कानूनों की समान सुरक्षा से वंचित नहीं करेगा।"

**इसका क्या मतलब है?**

1. **कानून के समक्ष समानता**: सभी व्यक्ति, जिनमें राष्ट्रपति और प्रधानमंत्री भी शामिल हैं, एक ही कानून के अधीन हैं। कोई भी कानून से ऊपर नहीं है।

2. **कानूनों की समान सुरक्षा**: कानूनों को एक जैसी परिस्थितियों में सभी व्यक्तियों पर समान रूप से लागू किया जाना चाहिए। राज्य मनमाने ढंग से भेदभाव नहीं कर सकता।

**मुख्य बातें:**
- नागरिकों और गैर-नागरिकों दोनों पर लागू होता है
- राज्य भेदभावपूर्ण कानून नहीं बना सकता
- यदि कोई कानून मनमाने ढंग से भेदभाव करता है, तो अदालत में चुनौती दी जा सकती है
- उचित वर्गीकरण की अनुमति है (उदाहरण के लिए, प्रगतिशील कराधान)

**उदाहरण:**
- किसी को जाति के आधार पर अपराध के लिए दंडित नहीं कर सकते
- धर्म के आधार पर रोजगार से वंचित नहीं कर सकते
- वैध आधार पर सेवानिवृत्ति के लिए अलग आयु योग्यता हो सकती है

यह अनुच्छेद भारत में समान नागरिकता की नींव है।`,

    संसद: `संसद भारत का सर्वोच्च विधायी निकाय है और इसमें शामिल हैं:

1. **राष्ट्रपति** (संवैधानिक भूमिका)

2. **लोक सभा (जनता का सदन)**
   - 545 सदस्य (530 राज्यों से, 15 संघ राज्य क्षेत्रों से, 2 आंग्ल-भारतीय)
   - जनता द्वारा हर 5 साल में सीधे चुने जाते हैं
   - वित्तीय मामलों में अधिक शक्तिशाली
   - कार्यकाल समाप्त होने से पहले भंग किया जा सकता है

3. **राज्य सभा (राज्यों की परिषद)**
   - 250 सदस्य (238 निर्वाचित, 12 मनोनीत)
   - राज्य विधानसभाओं द्वारा 6 साल के कार्यकाल के लिए चुने जाते हैं
   - हर 2 साल में 1/3 सदस्य सेवामुक्त होते हैं
   - राज्यों के हितों का प्रतिनिधित्व करता है

**संसद के कार्य:**
- देश के लिए कानून बनाना
- वित्त और बजट पर नियंत्रण
- करों और सरकारी खर्च को मंजूरी देना
- मंत्रियों से सवाल-जवाब करना और जवाबदेही सुनिश्चित करना
- संविधान में संशोधन करना

**विधेयक कानून कैसे बनता है:**
1. विधेयक किसी भी सदन में प्रस्तुत किया जाता है
2. चर्चा और बहस की जाती है
3. वोटिंग होती है
4. दूसरे सदन को भेजा जाता है
5. दूसरे सदन में वही प्रक्रिया होती है
6. दोनों द्वारा पारित होने पर राष्ट्रपति को भेजा जाता है
7. राष्ट्रपति की सहमति - विधेयक कानून बन जाता है

संसद भारतीय लोकतांत्रिक प्रणाली का दिल है।`,

    राष्ट्रपति: `राष्ट्रपति भारत में कार्यपालिका का संवैधानिक प्रमुख है।

**निर्वाचन:**
- निर्वाचक मंडल द्वारा चुना जाता है जिसमें शामिल हैं:
  - लोक सभा और राज्य सभा के सभी निर्वाचित सदस्य
  - राज्य विधानसभाओं के सभी निर्वाचित सदस्य
- समानता के लिए भारित मतदान प्रणाली का उपयोग करता है

**कार्यकाल:**
- 5 साल
- दूसरे कार्यकाल के लिए फिर से निर्वाचित हो सकता है
- दो लगातार पूर्ण कार्यकाल के बाद, पात्र नहीं है

**योग्यताएं:**
- भारतीय नागरिक
- कम से कम 35 साल की उम्र
- लोक सभा के लिए निर्वाचित होने के लिए योग्य
- दो लगातार कार्यकाल के लिए पद नहीं धारण किया है

**शक्तियां और कार्य:**
- प्रधानमंत्री की नियुक्ति करता है (लोक सभा में बहुमत का नेता)
- मुख्यमंत्री और राज्यपाल की नियुक्ति करता है
- संसद द्वारा पारित कानूनों को मंजूरी देता है
- क्षमादान दे सकता है
- सशस्त्र बलों का सर्वोच्च कमांडर
- संसद को संबोधित करता है
- लोक सभा को भंग कर सकता है

**सलाह पर कार्य:**
- राष्ट्रपति अधिकांश शक्तियों का प्रयोग प्रधानमंत्री और मंत्रिपरिषद की सलाह पर करता है
- कार्यों पर मंत्रिमंडल के सदस्यों के हस्ताक्षर होते हैं
- राष्ट्रपति मनमाने ढंग से कार्य नहीं कर सकता

राष्ट्रपति एक प्रतीकात्मक प्रमुख है, लेकिन संविधान के संरक्षक के रूप में महत्वपूर्ण प्रतीकात्मक शक्ति रखता है।`,

    "अनुच्छेद 17": `अनुच्छेद 17 संविधान के सबसे शक्तिशाली और महत्वपूर्ण अनुच्छेदों में से एक है: "अस्पृश्यता का अंत यहां घोषित किया जाता है और किसी भी रूप में इसका अभ्यास निषिद्ध है।"

**ऐतिहासिक महत्व:**
यह अनुच्छेद अस्पृश्यता की प्राचीन प्रथा को समाप्त करता है - एक जाति-आधारित प्रणाली जिसने कुछ समुदायों को "अस्पृश्य" घोषित किया था।

**इसका क्या मतलब है:**
- अस्पृश्यता पूरी तरह से निषिद्ध है
- अस्पृश्यता के आधार पर कोई भेदभाव नहीं कर सकते
- उल्लंघन आपराधिक अपराध हैं
- जाति के बावजूद सभी मनुष्यों की समान गरिमा

**डॉ. अंबेडकर का योगदान:**
यह अनुच्छेद डॉ. अंबेडकर के लिए विशेष रूप से महत्वपूर्ण था, जिन्होंने:
- स्वयं कड़े जाति-आधारित भेदभाव का सामना किया
- अपने पूरे जीवन में जाति-आधारित असमानता के खिलाफ लड़ाई लड़ी
- अस्पृश्यता का उन्मूलन संविधान का मूल सिद्धांत बनाया
- समानता और मानवीय गरिमा पर आधारित समाज की कल्पना की

**संबंधित अनुच्छेद:**
- अनुच्छेद 14: भेदभाव पर प्रतिबंध
- अनुच्छेद 15: जाति के आधार पर भेदभाव पर प्रतिबंध
- अनुच्छेद 16: सार्वजनिक रोजगार में समानता
- अनुच्छेद 23: बलात् श्रम पर प्रतिबंध

अस्पृश्यता का उन्मूलन भारत को एक सच्चे समतावादी समाज में बदलने के लिए एक क्रांतिकारी कदम था।`,

    "नीति निर्देशक सिद्धांत": `राज्य नीति के निर्देशक सिद्धांत (भाग IV, अनुच्छेद 36-51) शासन के लिए दिशानिर्देश हैं जो अदालतों में लागू नहीं किए जा सकते हैं लेकिन देश के शासन के लिए मौलिक हैं।

**मुख्य सिद्धांत:**

1. **सामाजिक और आर्थिक न्याय**
   - राज्य को कल्याण को बढ़ावा देना और असमानता को कम करना
   - सभ्य जीवन स्तर सुनिश्चित करना

2. **शिक्षा**
   - 14 साल तक की आयु के लिए मुफ्त और अनिवार्य शिक्षा
   - साक्षरता और सीखने को बढ़ावा देना

3. **जनस्वास्थ्य**
   - सार्वजनिक स्वास्थ्य और पोषण में सुधार
   - बीमारियों की रोकथाम

4. **पर्यावरण की सुरक्षा**
   - प्राकृतिक वातावरण की सुरक्षा और सुधार
   - वन्यजीव संरक्षण
   - स्मारकों और संस्कृति को संरक्षित करना

5. **श्रम अधिकार**
   - कार्य करने की न्यायसंगत परिस्थितियां सुनिश्चित करना
   - सामाजिक सुरक्षा और वृद्धावस्था लाभ
   - कार्मिकों की सुरक्षा

6. **कृषि और पशु कल्याण**
   - कृषि और पशुपालन में सुधार
   - पशु क्रूरता को रोकना

7. **अंतर्राष्ट्रीय शांति**
   - अंतर्राष्ट्रीय शांति और सुरक्षा को बढ़ावा देना
   - अंतर्राष्ट्रीय कानून का सम्मान करना

**क्यों लागू नहीं किए जा सकते?**
- आकांक्षात्मक लक्ष्य माने जाते हैं
- कार्यान्वयन के लिए संसाधनों और समय की आवश्यकता होती है
- लोकतांत्रिक सरकार के लिए लचीलापन

**महत्व:**
- कल्याणकारी राज्य के मूल्यों को प्रतिबिंबित करता है
- कानून बनाने और नीतियों को निर्देशित करता है
- समानता और सामाजिक न्याय की दृष्टि का प्रतिनिधित्व करता है

**कार्यान्वयन:**
- राज्य सिद्धांतों को लागू करने के लिए कानून बनाते हैं
- अदालतें कानूनों की व्याख्या करते समय उनका संदर्भ ले सकते हैं
- कई सिद्धांत अब संशोधनों के माध्यम से मौलिक अधिकारों में शामिल हैं

ये सिद्धांत डॉ. अंबेडकर के न्यायसंगत और समान समाज की दृष्टि को प्रतिबिंबित करते हैं।`,

    "अनुच्छेद 21": `अनुच्छेद 21: "कोई व्यक्ति को उसके जीवन या व्यक्तिगत स्वतंत्रता से वंचित नहीं किया जाएगा सिवाय कानून द्वारा स्थापित प्रक्रिया के अनुसार।"

**व्याख्या का विकास:**

शुरुआत में, इस अनुच्छेद की व्याख्या केवल प्रक्रियात्मक कानून के संदर्भ में की जाती थी। हालांकि, सर्वोच्च न्यायालय ने इसे व्यापक अधिकारों में विस्तारित किया है:

**अनुच्छेद 21 से प्राप्त अधिकार:**
- मानवीय गरिमा के साथ जीने का अधिकार
- स्वच्छ जल और हवा का अधिकार
- पर्याप्त भोजन और पोषण का अधिकार
- आश्रय का अधिकार
- शिक्षा का अधिकार
- स्वास्थ्य और चिकित्सा सेवा का अधिकार
- गोपनीयता का अधिकार
- आंदोलन की स्वतंत्रता
- निष्पक्ष सुनवाई का अधिकार

**ऐतिहासिक मामले:**
- मनेका गांधी बनाम भारत संघ: "प्रक्रिया" के अर्थ को विस्तारित किया
- ओल्गा तेलिस बनाम बॉम्बे नगरपालिका: जीविका का अधिकार
- सुखदेव सिंह बनाम पंजाब सरकार: न्याय का अधिकार

**सुरक्षा:**
- कानूनी प्रक्रिया के अलावा वंचित नहीं किया जा सकता
- कानून उचित, न्यायसंगत और उचित होना चाहिए
- मनमाना नहीं हो सकता

**सीमाएं:**
- मृत्यु दंड की अनुमति है (उचित प्रक्रिया के साथ)
- राज्य जनहित के लिए स्वतंत्रता को सीमित कर सकता है
- स्थापित कानून का पालन करना चाहिए

**महत्व:**
अनुच्छेद 21 मानवाधिकारों और गरिमा की सुरक्षा के लिए सबसे शक्तिशाली उपकरणों में से एक बन गया है। यह विभिन्न क्षेत्रों में अन्यायसंगत कानूनों और प्रथाओं को चुनौती देने के लिए उपयोग किया गया है।

यह अनुच्छेद वास्तव में एक संवैधानिक लोकतंत्र की दृष्टि को प्रतिबिंबित करता है जो मानवीय गरिमा की सुरक्षा करता है।`,
  },
}

export async function generateAmbedkarResponse(
  userQuestion: string | undefined,
  language: Language = "en",
): Promise<string> {
  await new Promise((resolve) => setTimeout(resolve, 800))

  if (!userQuestion || typeof userQuestion !== "string") {
    return language === "en"
      ? "I didn't quite understand that. Could you please rephrase your question about the Constitution?"
      : "मुझे यह समझ नहीं आया। क्या आप कृपया संविधान के बारे में अपने प्रश्न को फिर से तैयार कर सकते हैं?"
  }

  const lowerQuestion = userQuestion.toLowerCase()
  const langResponses = AI_RESPONSES[language]

  for (const [key, response] of Object.entries(langResponses)) {
    if (lowerQuestion.includes(key)) {
      return response
    }
  }

  const constitutionKeywords = ["constitution", "what is", "संविधान", "क्या है"]
  const isGeneralQuestion = constitutionKeywords.some((keyword) => lowerQuestion.includes(keyword))

  if (isGeneralQuestion) {
    return language === "en"
      ? `The Indian Constitution is the supreme law of India that outlines the structure and powers of the government, and the fundamental rights and duties of citizens.

**Key Facts:**
- Adopted on November 26, 1949
- Longest written constitution in the world
- 470 articles organized into 25 parts
- Drafted by the Constituent Assembly led by Dr. B.R. Ambedkar

**Main Components:**
1. **Preamble** - Sets out the objectives and principles
2. **Fundamental Rights** (Articles 12-35) - Basic rights guaranteed to all citizens
3. **Directive Principles** (Articles 36-51) - Guidelines for governance
4. **Government Structure** - Executive, Legislative, and Judicial branches
5. **Federal Structure** - Distribution of powers between Union and States

**Core Values:**
- Sovereignty - Independent nation
- Democracy - Power vested in people
- Secularism - No state religion
- Equality - Equal rights for all
- Justice - Social, economic, and political

The Constitution aims to establish a just and equal society where every citizen has rights and freedoms, regardless of caste, religion, gender, or other distinctions.

Would you like to know more about any specific aspect? You can ask about Fundamental Rights, Articles, Parliament, the President, or Dr. Ambedkar's role in drafting the Constitution!`
      : `भारतीय संविधान भारत का सर्वोच्च कानून है जो सरकार की संरचना और शक्तियों, और नागरिकों के मौलिक अधिकारों और कर्तव्यों को निर्धारित करता है।

**मुख्य तथ्य:**
- 26 नवंबर 1949 को अपनाया गया
- दुनिया का सबसे लंबा लिखित संविधान
- 470 अनुच्छेद 25 भागों में संगठित
- डॉ. बी.आर. अंबेडकर के नेतृत्व में संविधान सभा द्वारा तैयार

**मुख्य घटक:**
1. **प्रस्तावना** - उद्देश्यों और सिद्धांतों को निर्धारित करता है
2. **मौलिक अधिकार** (अनुच्छेद 12-35) - सभी नागरिकों को गारंटीकृत बुनियादी अधिकार
3. **नीति निर्देशक सिद्धांत** (अनुच्छेद 36-51) - शासन के दिशानिर्देश
4. **सरकारी संरचना** - कार्यकारी, विधायी और न्यायिक शाखाएं
5. **संघीय संरचना** - संघ और राज्यों के बीच शक्तियों का वितरण

**मुख्य मूल्य:**
- संप्रभुता - स्वतंत्र राष्ट्र
- लोकतंत्र - शक्ति जनता में
- पंथनिरपेक्षता - कोई राज्य धर्म नहीं
- समानता - सभी के लिए समान अधिकार
- न्याय - सामाजिक, आर्थिक और राजनीतिक

संविधान का लक्ष्य एक न्यायसंगत और समान समाज स्थापित करना है जहां हर नागरिक को अधिकार और स्वतंत्रता है।

क्या आप किसी विशिष्ट पहलू के बारे में अधिक जानना चाहते हैं? आप मौलिक अधिकारों, अनुच्छेदों, संसद, राष्ट्रपति, या डॉ. अंबेडकर की संविधान में भूमिका के बारे में पूछ सकते हैं!`
  }

  for (const page of CONSTITUTION_PAGES) {
    const pageTitle = language === "en" ? page.titleEn : page.titleHi
    const pageContent = language === "en" ? page.contentEn : page.contentHi
    const pageText = (pageTitle + " " + pageContent).toLowerCase()

    if (lowerQuestion.split(" ").some((word) => word.length > 3 && pageText.includes(word))) {
      return language === "en"
        ? `Based on the Constitution, here's relevant information:\n\n**${pageTitle}**\n\n${pageContent.substring(0, 600)}...\n\nFor more detailed information, you can read the full Constitution using the "Read" section, or ask me specific questions about particular articles or concepts.`
        : `संविधान के आधार पर, यहां प्रासंगिक जानकारी दी गई है:\n\n**${pageTitle}**\n\n${pageContent.substring(0, 600)}...\n\nअधिक विस्तृत जानकारी के लिए, आप "पढ़ें" अनुभाग का उपयोग करके पूरे संविधान को पढ़ सकते हैं, या मुझसे विशिष्ट अनुच्छेदों या अवधारणाओं के बारे में प्रश्न पूछ सकते हैं।`
    }
  }

  return language === "en"
    ? `I appreciate your question about the Constitution. While I can answer questions about constitutional topics, I'd like to help you better.

**Try asking me about:**
- Fundamental Rights (Articles 14-35)
- Articles 14, 15, 17, 19, 21, 22 (specific rights)
- Parliament and how laws are made
- The President's role and powers
- Directive Principles of State Policy
- Dr. Ambedkar's contribution to the Constitution
- Any specific constitutional concept

**For example, you could ask:**
- "What are Fundamental Rights?"
- "What is Article 14?"
- "How does Parliament work?"
- "What did Dr. Ambedkar do?"

Would you like to rephrase your question? I'm here to help you understand the Indian Constitution better!`
    : `मैं संविधान के बारे में आपके प्रश्न की सराहना करता हूँ। जबकि मैं संवैधानिक विषयों के बारे में प्रश्नों का उत्तर दे सकता हूँ, मैं आपको बेहतर तरीके से मदद करना चाहता हूँ।

**मुझसे पूछने का प्रयास करें:**
- मौलिक अधिकार (अनुच्छेद 14-35)
- अनुच्छेद 14, 15, 17, 19, 21, 22 (विशिष्ट अधिकार)
- संसद और कानून कैसे बनते हैं
- राष्ट्रपति की भूमिका और शक्तियां
- राज्य नीति के निर्देशक सिद्धांत
- डॉ. अंबेडकर का संविधान में योगदान
- कोई भी विशिष्ट संवैधानिक अवधारणा

**उदाहरण के लिए, आप पूछ सकते हैं:**
- "मौलिक अधिकार क्या हैं?"
- "अनुच्छेद 14 क्या है?"
- "संसद कैसे काम करती है?"
- "डॉ. अंबेडकर ने क्या किया?"

क्या आप अपने प्रश्न को दोबारा तैयार करना चाहते हैं? मैं आपको भारतीय संविधान को बेहतर तरीके से समझने में मदद करने के लिए यहाँ हूँ!`
}
